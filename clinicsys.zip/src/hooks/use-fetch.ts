"use client";

import { useCallback, useEffect, useState } from "react";

interface State<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

/**
 * Simple data fetching hook with manual refresh.
 *
 * `deps` controls automatic refetch — pass the values the fetcher depends on.
 * The fetcher itself is intentionally not a dependency: callers typically pass
 * inline closures, and `deps` already captures their inputs.
 */
export function useFetch<T>(fetcher: () => Promise<T>, deps: unknown[] = []) {
  const [state, setState] = useState<State<T>>({ data: null, loading: true, error: null });
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    let active = true;
    // Standard data-fetching effect: flag loading before the async request resolves.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setState((s) => ({ ...s, loading: true, error: null }));
    fetcher()
      .then((data) => {
        if (active) setState({ data, loading: false, error: null });
      })
      .catch((e) => {
        if (active) {
          setState({ data: null, loading: false, error: String(e?.message ?? e) });
        }
      });
    return () => {
      active = false;
    };
  }, [refreshKey, ...deps]);

  const refresh = useCallback(() => setRefreshKey((k) => k + 1), []);
  return { ...state, refresh };
}
