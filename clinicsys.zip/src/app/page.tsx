import { AppShell } from "@/components/clinic/app-shell";

export default function Home() {
  return <AppShell />;
}
