import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isValidGender } from "@/lib/clinic";

// GET /api/patients?search=&limit=
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const search = searchParams.get("search")?.trim() ?? "";
    const limit = Number(searchParams.get("limit")) || 0;

    const where = search
      ? {
          OR: [
            { name: { contains: search } },
            { phone: { contains: search } },
            { email: { contains: search } },
          ],
        }
      : {};

    const patients = await db.patient.findMany({
      where,
      orderBy: { createdAt: "desc" },
      ...(limit ? { take: limit } : {}),
      include: {
        _count: { select: { appointments: true, visits: true } },
      },
    });

    return NextResponse.json({ patients });
  } catch (e) {
    console.error("GET /api/patients error:", e);
    return NextResponse.json({ error: "Failed to fetch patients" }, { status: 500 });
  }
}

// POST /api/patients
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, phone, email, gender, birthDate, address, bloodType, allergies, conditions, notes } = body;

    if (!name || typeof name !== "string" || !name.trim()) {
      return NextResponse.json({ error: "Patient name is required" }, { status: 400 });
    }
    if (!phone || typeof phone !== "string" || !phone.trim()) {
      return NextResponse.json({ error: "Phone number is required" }, { status: 400 });
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: "Invalid email format" }, { status: 400 });
    }
    if (gender && !isValidGender(gender)) {
      return NextResponse.json({ error: "Invalid gender value" }, { status: 400 });
    }

    const existing = await db.patient.findFirst({ where: { phone: phone.trim() } });
    if (existing) {
      return NextResponse.json({ error: "A patient with this phone number already exists" }, { status: 409 });
    }

    const patient = await db.patient.create({
      data: {
        name: name.trim(),
        phone: phone.trim(),
        email: email?.trim() || null,
        gender: gender ?? "unknown",
        birthDate: birthDate || null,
        address: address || null,
        bloodType: bloodType || null,
        allergies: allergies || null,
        conditions: conditions || null,
        notes: notes || null,
      },
    });

    return NextResponse.json({ patient }, { status: 201 });
  } catch (e) {
    console.error("POST /api/patients error:", e);
    return NextResponse.json({ error: "Failed to create patient" }, { status: 500 });
  }
}
