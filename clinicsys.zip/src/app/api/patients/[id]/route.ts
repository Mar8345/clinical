import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isValidGender } from "@/lib/clinic";

// GET /api/patients/[id]
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const patient = await db.patient.findUnique({
      where: { id },
      include: {
        appointments: {
          include: { doctor: true, visit: true },
          orderBy: { date: "desc" },
        },
        visits: {
          include: { doctor: true },
          orderBy: { visitDate: "desc" },
        },
      },
    });
    if (!patient) {
      return NextResponse.json({ error: "Patient not found" }, { status: 404 });
    }
    return NextResponse.json({ patient });
  } catch (e) {
    console.error("GET /api/patients/[id] error:", e);
    return NextResponse.json({ error: "Failed to fetch patient" }, { status: 500 });
  }
}

// PUT /api/patients/[id]
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const { name, phone, email, gender, birthDate, address, bloodType, allergies, conditions, notes } = body;

    const existing = await db.patient.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Patient not found" }, { status: 404 });
    }
    if (!name?.trim()) {
      return NextResponse.json({ error: "Patient name is required" }, { status: 400 });
    }
    if (!phone?.trim()) {
      return NextResponse.json({ error: "Phone number is required" }, { status: 400 });
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: "Invalid email format" }, { status: 400 });
    }
    if (gender && !isValidGender(gender)) {
      return NextResponse.json({ error: "Invalid gender value" }, { status: 400 });
    }

    if (phone.trim() !== existing.phone) {
      const dup = await db.patient.findFirst({ where: { phone: phone.trim(), NOT: { id } } });
      if (dup) {
        return NextResponse.json({ error: "Another patient with this phone already exists" }, { status: 409 });
      }
    }

    const updated = await db.patient.update({
      where: { id },
      data: {
        name: name.trim(),
        phone: phone.trim(),
        email: email?.trim() || null,
        gender: gender ?? existing.gender,
        birthDate: birthDate || null,
        address: address || null,
        bloodType: bloodType || null,
        allergies: allergies || null,
        conditions: conditions || null,
        notes: notes || null,
      },
    });
    return NextResponse.json({ patient: updated });
  } catch (e) {
    console.error("PUT /api/patients/[id] error:", e);
    return NextResponse.json({ error: "Failed to update patient" }, { status: 500 });
  }
}

// DELETE /api/patients/[id]
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const existing = await db.patient.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Patient not found" }, { status: 404 });
    }
    await db.patient.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (e) {
    console.error("DELETE /api/patients/[id] error:", e);
    return NextResponse.json({ error: "Failed to delete patient" }, { status: 500 });
  }
}
