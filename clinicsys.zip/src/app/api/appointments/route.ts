import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isValidStatus, todayISO } from "@/lib/clinic";

// GET /api/appointments?date=&status=&doctorId=&from=&to=&upcoming=
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const date = searchParams.get("date");
    const status = searchParams.get("status");
    const doctorId = searchParams.get("doctorId");
    const from = searchParams.get("from");
    const to = searchParams.get("to");
    const upcoming = searchParams.get("upcoming") === "true";

    const where: Record<string, unknown> = {};
    if (date) where.date = date;
    if (status && isValidStatus(status)) where.status = status;
    if (doctorId) where.doctorId = doctorId;
    if (from || to) {
      where.date = {};
      if (from) (where.date as Record<string, unknown>).gte = from;
      if (to) (where.date as Record<string, unknown>).lte = to;
    }
    if (upcoming) {
      where.date = { gte: todayISO() };
      where.status = { in: ["pending", "confirmed"] };
    }

    const appointments = await db.appointment.findMany({
      where,
      include: { patient: true, doctor: true, visit: true },
      orderBy: [{ date: "asc" }, { time: "asc" }],
    });

    return NextResponse.json({ appointments });
  } catch (e) {
    console.error("GET /api/appointments error:", e);
    return NextResponse.json({ error: "Failed to fetch appointments" }, { status: 500 });
  }
}

// POST /api/appointments
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { patientId, doctorId, date, time, durationMin, status, reason, notes } = body;

    if (!patientId) return NextResponse.json({ error: "Patient is required" }, { status: 400 });
    if (!doctorId) return NextResponse.json({ error: "Doctor is required" }, { status: 400 });
    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return NextResponse.json({ error: "Valid date is required (YYYY-MM-DD)" }, { status: 400 });
    if (!time || !/^\d{2}:\d{2}$/.test(time)) return NextResponse.json({ error: "Valid time is required (HH:mm)" }, { status: 400 });

    const [patient, doctor] = await Promise.all([
      db.patient.findUnique({ where: { id: patientId } }),
      db.doctor.findUnique({ where: { id: doctorId } }),
    ]);
    if (!patient) return NextResponse.json({ error: "Patient not found" }, { status: 404 });
    if (!doctor) return NextResponse.json({ error: "Doctor not found" }, { status: 404 });

    // Check for time conflicts on same doctor + date + time
    const conflict = await db.appointment.findFirst({
      where: { doctorId, date, time, status: { in: ["pending", "confirmed"] } },
    });
    if (conflict) {
      return NextResponse.json({ error: "Doctor already has an appointment at this time" }, { status: 409 });
    }

    const appt = await db.appointment.create({
      data: {
        patientId,
        doctorId,
        date,
        time,
        durationMin: Number(durationMin) || 30,
        status: isValidStatus(status) ? status : "pending",
        reason: reason || null,
        notes: notes || null,
      },
      include: { patient: true, doctor: true },
    });
    return NextResponse.json({ appointment: appt }, { status: 201 });
  } catch (e) {
    console.error("POST /api/appointments error:", e);
    return NextResponse.json({ error: "Failed to create appointment" }, { status: 500 });
  }
}
