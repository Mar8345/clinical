import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isValidStatus } from "@/lib/clinic";

// PATCH /api/appointments/[id] — update status / reschedule
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const { status, date, time, reason, notes, durationMin } = body;

    const existing = await db.appointment.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Appointment not found" }, { status: 404 });
    }

    const data: Record<string, unknown> = {};
    if (status !== undefined) {
      if (!isValidStatus(status)) {
        return NextResponse.json({ error: "Invalid status" }, { status: 400 });
      }
      data.status = status;
    }
    if (date !== undefined) {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return NextResponse.json({ error: "Invalid date" }, { status: 400 });
      data.date = date;
    }
    if (time !== undefined) {
      if (!/^\d{2}:\d{2}$/.test(time)) return NextResponse.json({ error: "Invalid time" }, { status: 400 });
      data.time = time;
    }
    if (reason !== undefined) data.reason = reason;
    if (notes !== undefined) data.notes = notes;
    if (durationMin !== undefined) data.durationMin = Number(durationMin);

    // Conflict check if rescheduling
    if ((date || time) && existing.status !== "cancelled" && existing.status !== "completed") {
      const newDate = (date as string) || existing.date;
      const newTime = (time as string) || existing.time;
      const conflict = await db.appointment.findFirst({
        where: {
          doctorId: existing.doctorId,
          date: newDate,
          time: newTime,
          status: { in: ["pending", "confirmed"] },
          NOT: { id },
        },
      });
      if (conflict) {
        return NextResponse.json({ error: "Doctor already has an appointment at this time" }, { status: 409 });
      }
    }

    const updated = await db.appointment.update({
      where: { id },
      data,
      include: { patient: true, doctor: true, visit: true },
    });
    return NextResponse.json({ appointment: updated });
  } catch (e) {
    console.error("PATCH /api/appointments/[id] error:", e);
    return NextResponse.json({ error: "Failed to update appointment" }, { status: 500 });
  }
}

// DELETE /api/appointments/[id]
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const existing = await db.appointment.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Appointment not found" }, { status: 404 });
    }
    await db.appointment.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (e) {
    console.error("DELETE /api/appointments/[id] error:", e);
    return NextResponse.json({ error: "Failed to delete appointment" }, { status: 500 });
  }
}
