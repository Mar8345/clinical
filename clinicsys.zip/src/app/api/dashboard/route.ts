import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { todayISO, addDaysISO } from "@/lib/clinic";

// GET /api/dashboard — aggregate stats for doctor/secretary dashboard
export async function GET() {
  try {
    const today = todayISO();

    const [
      totalPatients,
      totalDoctors,
      totalAppointments,
      totalVisits,
      todayAppointments,
      upcomingAppointments,
      statusCountsRaw,
      last14DaysAppts,
      visitsWithFee,
      recentVisits,
      doctorLoad,
    ] = await Promise.all([
      db.patient.count(),
      db.doctor.count(),
      db.appointment.count(),
      db.visit.count(),
      db.appointment.findMany({
        where: { date: today },
        include: { patient: true, doctor: true },
        orderBy: { time: "asc" },
      }),
      db.appointment.findMany({
        where: { date: { gt: today }, status: { in: ["pending", "confirmed"] } },
        include: { patient: true, doctor: true },
        orderBy: [{ date: "asc" }, { time: "asc" }],
        take: 8,
      }),
      db.appointment.groupBy({ by: ["status"], _count: true }),
      db.appointment.findMany({
        where: { date: { gte: addDaysISO(today, -13), lte: today } },
        select: { date: true, status: true },
      }),
      db.visit.findMany({ select: { fee: true, visitDate: true } }),
      db.visit.findMany({
        include: { patient: true, doctor: true },
        orderBy: { visitDate: "desc" },
        take: 6,
      }),
      db.appointment.groupBy({
        by: ["doctorId"],
        _count: true,
      }),
    ]);

    // Status distribution
    const statusCounts: Record<string, number> = {
      pending: 0,
      confirmed: 0,
      completed: 0,
      cancelled: 0,
      no_show: 0,
    };
    for (const s of statusCountsRaw) {
      statusCounts[s.status] = s._count;
    }

    // Appointments per day for last 14 days
    const dayMap = new Map<string, { date: string; total: number; completed: number }>();
    for (let i = 13; i >= 0; i--) {
      const iso = addDaysISO(today, -i);
      dayMap.set(iso, { date: iso, total: 0, completed: 0 });
    }
    for (const a of last14DaysAppts) {
      const entry = dayMap.get(a.date);
      if (entry) {
        entry.total += 1;
        if (a.status === "completed") entry.completed += 1;
      }
    }

    // Revenue (sum of visit fees)
    const revenue = visitsWithFee.reduce((sum, v) => sum + (v.fee || 0), 0);

    // Doctor names for load
    const doctors = await db.doctor.findMany();
    const doctorNameMap = new Map(doctors.map((d) => [d.id, d]));
    const doctorLoadData = doctorLoad.map((d) => ({
      doctor: doctorNameMap.get(d.doctorId)?.name ?? "Unknown",
      specialty: doctorNameMap.get(d.doctorId)?.specialty ?? "",
      count: d._count,
    }));

    return NextResponse.json({
      totals: {
        patients: totalPatients,
        doctors: totalDoctors,
        appointments: totalAppointments,
        visits: totalVisits,
        revenue,
        todayCount: todayAppointments.length,
        upcomingCount: upcomingAppointments.length,
      },
      todayAppointments,
      upcomingAppointments,
      statusCounts,
      last14Days: Array.from(dayMap.values()),
      recentVisits,
      doctorLoad: doctorLoadData,
    });
  } catch (e) {
    console.error("Dashboard error:", e);
    return NextResponse.json({ error: "Failed to load dashboard", detail: String(e) }, { status: 500 });
  }
}
