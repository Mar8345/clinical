import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/visits?patientId=&doctorId=&limit=
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const patientId = searchParams.get("patientId");
    const doctorId = searchParams.get("doctorId");
    const limit = Number(searchParams.get("limit")) || 0;

    const where: Record<string, unknown> = {};
    if (patientId) where.patientId = patientId;
    if (doctorId) where.doctorId = doctorId;

    const visits = await db.visit.findMany({
      where,
      include: { patient: true, doctor: true, appointment: true },
      orderBy: { visitDate: "desc" },
      ...(limit ? { take: limit } : {}),
    });
    return NextResponse.json({ visits });
  } catch (e) {
    console.error("GET /api/visits error:", e);
    return NextResponse.json({ error: "Failed to fetch visits" }, { status: 500 });
  }
}

// POST /api/visits
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      patientId,
      doctorId,
      appointmentId,
      visitDate,
      diagnosis,
      prescription,
      notes,
      temperature,
      bloodPressure,
      weight,
      height,
      fee,
      followUpDate,
    } = body;

    if (!patientId) return NextResponse.json({ error: "Patient is required" }, { status: 400 });
    if (!doctorId) return NextResponse.json({ error: "Doctor is required" }, { status: 400 });
    if (!diagnosis?.trim()) return NextResponse.json({ error: "Diagnosis is required" }, { status: 400 });

    const [patient, doctor] = await Promise.all([
      db.patient.findUnique({ where: { id: patientId } }),
      db.doctor.findUnique({ where: { id: doctorId } }),
    ]);
    if (!patient) return NextResponse.json({ error: "Patient not found" }, { status: 404 });
    if (!doctor) return NextResponse.json({ error: "Doctor not found" }, { status: 404 });

    const visit = await db.visit.create({
      data: {
        patientId,
        doctorId,
        appointmentId: appointmentId || null,
        visitDate: visitDate ? new Date(visitDate) : new Date(),
        diagnosis: diagnosis.trim(),
        prescription: prescription || null,
        notes: notes || null,
        temperature: temperature || null,
        bloodPressure: bloodPressure || null,
        weight: weight || null,
        height: height || null,
        fee: Number(fee) || 0,
        followUpDate: followUpDate || null,
      },
      include: { patient: true, doctor: true },
    });

    // If linked to an appointment, mark it completed
    if (appointmentId) {
      await db.appointment.updateMany({
        where: { id: appointmentId },
        data: { status: "completed" },
      });
    }

    return NextResponse.json({ visit }, { status: 201 });
  } catch (e) {
    console.error("POST /api/visits error:", e);
    return NextResponse.json({ error: "Failed to create visit" }, { status: 500 });
  }
}
