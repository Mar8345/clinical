import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// PUT /api/visits/[id]
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const { diagnosis, prescription, notes, temperature, bloodPressure, weight, height, fee, followUpDate } = body;

    const existing = await db.visit.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Visit not found" }, { status: 404 });
    }
    if (diagnosis !== undefined && !diagnosis?.trim()) {
      return NextResponse.json({ error: "Diagnosis cannot be empty" }, { status: 400 });
    }

    const updated = await db.visit.update({
      where: { id },
      data: {
        diagnosis: diagnosis?.trim() ?? existing.diagnosis,
        prescription: prescription ?? existing.prescription,
        notes: notes ?? existing.notes,
        temperature: temperature ?? existing.temperature,
        bloodPressure: bloodPressure ?? existing.bloodPressure,
        weight: weight ?? existing.weight,
        height: height ?? existing.height,
        fee: fee !== undefined ? Number(fee) : existing.fee,
        followUpDate: followUpDate ?? existing.followUpDate,
      },
      include: { patient: true, doctor: true },
    });
    return NextResponse.json({ visit: updated });
  } catch (e) {
    console.error("PUT /api/visits/[id] error:", e);
    return NextResponse.json({ error: "Failed to update visit" }, { status: 500 });
  }
}

// DELETE /api/visits/[id]
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const existing = await db.visit.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Visit not found" }, { status: 404 });
    }
    await db.visit.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (e) {
    console.error("DELETE /api/visits/[id] error:", e);
    return NextResponse.json({ error: "Failed to delete visit" }, { status: 500 });
  }
}
