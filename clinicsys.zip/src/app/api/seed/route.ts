import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { todayISO, addDaysISO } from "@/lib/clinic";

// POST /api/seed — populate sample data (clears then seeds)
export async function POST() {
  try {
    // Clean existing data
    await db.visit.deleteMany();
    await db.appointment.deleteMany();
    await db.patient.deleteMany();
    await db.doctor.deleteMany();

    const doctors = await db.doctor.createMany({
      data: [
        {
          name: "Dr. Sarah Mensah",
          specialty: "General Practitioner",
          email: "sarah.mensah@mediclinic.io",
          phone: "+20 100 123 4567",
          bio: "Family medicine with 12 years experience in primary care.",
          color: "teal",
        },
        {
          name: "Dr. Omar Khalil",
          specialty: "Cardiologist",
          email: "omar.khalil@mediclinic.io",
          phone: "+20 100 234 5678",
          bio: "Interventional cardiology & hypertension management.",
          color: "rose",
        },
        {
          name: "Dr. Amira Hassan",
          specialty: "Pediatrician",
          email: "amira.hassan@mediclinic.io",
          phone: "+20 100 345 6789",
          bio: "Child wellness, vaccinations and developmental checks.",
          color: "amber",
        },
        {
          name: "Dr. James Okoro",
          specialty: "Dermatologist",
          email: "james.okoro@mediclinic.io",
          phone: "+20 100 456 7890",
          bio: "Skin, hair and nail disorders. Minor procedures.",
          color: "emerald",
        },
      ],
    });

    const allDoctors = await db.doctor.findMany({ orderBy: { createdAt: "asc" } });
    const [drSarah, drOmar, drAmira, drJames] = allDoctors;

    const patientsData = [
      { name: "Mariam Abdelaziz", phone: "+20 122 111 2222", email: "mariam.a@example.com", gender: "female", birthDate: "1991-04-18", address: "12 Tahrir St, Cairo", bloodType: "A+", allergies: "Penicillin", conditions: "Asthma" },
      { name: "Youssef Nabil", phone: "+20 122 333 4444", email: "youssef.n@example.com", gender: "male", birthDate: "1985-09-02", address: "5 Pyramids Rd, Giza", bloodType: "O+", allergies: "", conditions: "Hypertension" },
      { name: "Layla Farouk", phone: "+20 122 555 6666", email: "layla.f@example.com", gender: "female", birthDate: "1998-12-25", address: "88 Nile St, Cairo", bloodType: "B+", allergies: "Latex", conditions: "" },
      { name: "Khaled Saeed", phone: "+20 122 777 8888", email: "khaled.s@example.com", gender: "male", birthDate: "1972-02-14", address: "3 Sekem Rd, Belbis", bloodType: "AB+", allergies: "", conditions: "Type 2 Diabetes" },
      { name: "Nour El-Din", phone: "+20 122 999 0000", email: "nour.e@example.com", gender: "male", birthDate: "2001-06-30", address: "14 Gamal St, Alexandria", bloodType: "A-", allergies: "", conditions: "" },
      { name: "Hana Mostafa", phone: "+20 122 101 1213", email: "hana.m@example.com", gender: "female", birthDate: "2015-03-11", address: "7 Smouha, Alexandria", bloodType: "O-", allergies: "Peanuts", conditions: "" },
      { name: "Tarek Zaki", phone: "+20 122 141 5161", email: "tarek.z@example.com", gender: "male", birthDate: "1960-11-05", address: "22 Mansoura Rd, Talkha", bloodType: "B-", allergies: "", conditions: "Coronary artery disease" },
      { name: "Salma Adel", phone: "+20 122 171 8191", email: "salma.a@example.com", gender: "female", birthDate: "1995-08-19", address: "9 Maadi St, Cairo", bloodType: "AB-", allergies: "Sulfa drugs", conditions: "Migraine" },
    ];

    await db.patient.createMany({ data: patientsData });
    const allPatients = await db.patient.findMany({ orderBy: { createdAt: "asc" } });
    const [pMariam, pYoussef, pLayla, pKhaled, pNour, pHana, pTarek, pSalma] = allPatients;

    const today = todayISO();
    const d1 = addDaysISO(today, 1);
    const d2 = addDaysISO(today, 2);
    const d3 = addDaysISO(today, 3);
    const dMinus1 = addDaysISO(today, -1);
    const dMinus2 = addDaysISO(today, -2);
    const dMinus5 = addDaysISO(today, -5);
    const dMinus8 = addDaysISO(today, -8);
    const dMinus12 = addDaysISO(today, -12);

    const appointments = [
      { patient: pMariam, doctor: drSarah, date: today, time: "09:00", status: "confirmed", reason: "Routine check-up" },
      { patient: pYoussef, doctor: drOmar, date: today, time: "10:00", status: "confirmed", reason: "Blood pressure follow-up" },
      { patient: pHana, doctor: drAmira, date: today, time: "11:30", status: "pending", reason: "Vaccination" },
      { patient: pLayla, doctor: drJames, date: today, time: "13:00", status: "completed", reason: "Skin rash" },
      { patient: pSalma, doctor: drSarah, date: today, time: "15:00", status: "pending", reason: "Headache & migraine" },
      { patient: pKhaled, doctor: drOmar, date: d1, time: "09:30", status: "confirmed", reason: "Diabetes review" },
      { patient: pNour, doctor: drJames, date: d1, time: "11:00", status: "pending", reason: "Acne treatment" },
      { patient: pTarek, doctor: drOmar, date: d2, time: "10:00", status: "confirmed", reason: "Chest pain assessment" },
      { patient: pHana, doctor: drAmira, date: d2, time: "12:00", status: "confirmed", reason: "Growth check" },
      { patient: pMariam, doctor: drSarah, date: d3, time: "14:00", status: "pending", reason: "Asthma review" },
      { patient: pLayla, doctor: drSarah, date: dMinus1, time: "09:00", status: "completed", reason: "Annual physical" },
      { patient: pKhaled, doctor: drOmar, date: dMinus1, time: "10:30", status: "no_show", reason: "BP follow-up" },
      { patient: pSalma, doctor: drSarah, date: dMinus2, time: "15:30", status: "cancelled", reason: "Migraine" },
      { patient: pYoussef, doctor: drOmar, date: dMinus5, time: "11:00", status: "completed", reason: "ECG" },
      { patient: pTarek, doctor: drJames, date: dMinus8, time: "13:30", status: "completed", reason: "Eczema" },
      { patient: pHana, doctor: drAmira, date: dMinus12, time: "10:00", status: "completed", reason: "Vaccination" },
    ];

    const createdAppts: { id: string; patientId: string; doctorId: string; date: string; time: string }[] = [];
    for (const a of appointments) {
      const created = await db.appointment.create({
        data: {
          patientId: a.patient.id,
          doctorId: a.doctor.id,
          date: a.date,
          time: a.time,
          durationMin: 30,
          status: a.status,
          reason: a.reason,
        },
      });
      createdAppts.push({ id: created.id, patientId: a.patient.id, doctorId: a.doctor.id, date: a.date, time: a.time });
    }

    const completedAppts = createdAppts.filter((a) => {
      const orig = appointments.find((x) => x.patient.id === a.patientId && x.doctor.id === a.doctorId && x.date === a.date && x.time === a.time);
      return orig?.status === "completed";
    });

    const diagnosisPool = [
      "Acute bronchitis",
      "Essential hypertension",
      "Migraine without aura",
      "Atopic dermatitis",
      "Type 2 diabetes mellitus — controlled",
      "Upper respiratory tract infection",
      "Contact dermatitis",
      "Bronchial asthma — mild intermittent",
    ];

    for (const a of completedAppts) {
      const dt = new Date(`${a.date}T${a.time}:00`);
      await db.visit.create({
        data: {
          patientId: a.patientId,
          doctorId: a.doctorId,
          appointmentId: a.id,
          visitDate: dt,
          diagnosis: diagnosisPool[Math.floor(Math.random() * diagnosisPool.length)],
          prescription: "Rest, fluids, paracetamol 500mg PRN. Return if symptoms persist.",
          notes: "Patient responded well to initial guidance.",
          temperature: "37.1",
          bloodPressure: "120/80",
          weight: "72",
          height: "170",
          fee: 250,
        },
      });
    }

    return NextResponse.json({
      success: true,
      message: "Seed complete",
      counts: {
        doctors: allDoctors.length,
        patients: allPatients.length,
        appointments: createdAppts.length,
        visits: completedAppts.length,
      },
    });
  } catch (e) {
    console.error("Seed error:", e);
    return NextResponse.json({ error: "Seed failed", detail: String(e) }, { status: 500 });
  }
}
