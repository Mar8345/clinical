import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// PUT /api/doctors/[id]
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const { name, specialty, email, phone, bio, color, active } = body;

    const existing = await db.doctor.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Doctor not found" }, { status: 404 });
    }
    if (!name?.trim()) return NextResponse.json({ error: "Doctor name is required" }, { status: 400 });
    if (!specialty?.trim()) return NextResponse.json({ error: "Specialty is required" }, { status: 400 });

    const updated = await db.doctor.update({
      where: { id },
      data: {
        name: name.trim(),
        specialty: specialty.trim(),
        email: email?.trim() || null,
        phone: phone?.trim() || null,
        bio: bio || null,
        color: color || existing.color,
        active: typeof active === "boolean" ? active : existing.active,
      },
    });
    return NextResponse.json({ doctor: updated });
  } catch (e) {
    console.error("PUT /api/doctors/[id] error:", e);
    return NextResponse.json({ error: "Failed to update doctor" }, { status: 500 });
  }
}

// DELETE /api/doctors/[id]
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const existing = await db.doctor.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Doctor not found" }, { status: 404 });
    }
    await db.doctor.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (e) {
    console.error("DELETE /api/doctors/[id] error:", e);
    return NextResponse.json({ error: "Failed to delete doctor" }, { status: 500 });
  }
}
