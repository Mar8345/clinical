import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/doctors
export async function GET() {
  try {
    const doctors = await db.doctor.findMany({
      orderBy: { createdAt: "asc" },
      include: { _count: { select: { appointments: true, visits: true } } },
    });
    return NextResponse.json({ doctors });
  } catch (e) {
    console.error("GET /api/doctors error:", e);
    return NextResponse.json({ error: "Failed to fetch doctors" }, { status: 500 });
  }
}

// POST /api/doctors
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, specialty, email, phone, bio, color, active } = body;

    if (!name?.trim()) {
      return NextResponse.json({ error: "Doctor name is required" }, { status: 400 });
    }
    if (!specialty?.trim()) {
      return NextResponse.json({ error: "Specialty is required" }, { status: 400 });
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: "Invalid email format" }, { status: 400 });
    }

    const doctor = await db.doctor.create({
      data: {
        name: name.trim(),
        specialty: specialty.trim(),
        email: email?.trim() || null,
        phone: phone?.trim() || null,
        bio: bio || null,
        color: color || "teal",
        active: active ?? true,
      },
    });
    return NextResponse.json({ doctor }, { status: 201 });
  } catch (e) {
    console.error("POST /api/doctors error:", e);
    return NextResponse.json({ error: "Failed to create doctor" }, { status: 500 });
  }
}
