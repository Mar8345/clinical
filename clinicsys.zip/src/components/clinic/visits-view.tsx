"use client";

import { useMemo, useState } from "react";
import { api } from "@/lib/api";
import { useFetch } from "@/hooks/use-fetch";
import type { Doctor, Patient, Visit } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Stethoscope, Trash2, Pencil, Thermometer, Activity, CalendarClock } from "lucide-react";
import { Avatar, EmptyState, LoadingState, SectionHeader } from "./shared";
import { VisitFormDialog } from "./visit-form-dialog";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface Props {
  patients: Patient[];
  doctors: Doctor[];
  refreshKey: number;
  openSignal?: { patientId: string; ts: number } | null;
  onChanged: () => void;
}

export function VisitsView({ patients, doctors, refreshKey, openSignal, onChanged }: Props) {
  const [doctorFilter, setDoctorFilter] = useState<string>("all");
  const [addOpen, setAddOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Visit | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Visit | null>(null);
  const [defaultPatientId, setDefaultPatientId] = useState<string | undefined>(undefined);

  // Open add dialog when triggered from patient detail (render-time state adjust)
  const [prevSignalTs, setPrevSignalTs] = useState<number | null>(null);
  if (openSignal && openSignal.ts !== prevSignalTs) {
    setPrevSignalTs(openSignal.ts);
    setDefaultPatientId(openSignal.patientId);
    setAddOpen(true);
  }

  const fetcher = useMemo(
    () => () => api.listVisits(doctorFilter === "all" ? {} : { doctorId: doctorFilter }),
    [doctorFilter],
  );
  const { data, loading, error, refresh } = useFetch(fetcher, [doctorFilter, refreshKey]);

  const visits = data?.visits ?? [];

  async function handleDelete() {
    if (!deleteTarget) return;
    try {
      await api.deleteVisit(deleteTarget.id);
      toast.success("Visit deleted");
      setDeleteTarget(null);
      refresh();
      onChanged();
    } catch (e) {
      toast.error("Failed to delete", { description: String((e as Error).message) });
    }
  }

  return (
    <div className="space-y-5">
      <SectionHeader
        title="Visit History"
        description="Clinical encounters, diagnoses and prescriptions."
        icon={Stethoscope}
        action={
          <Button
            onClick={() => {
              setDefaultPatientId(undefined);
              setAddOpen(true);
            }}
            className="shadow-sm"
          >
            <Plus className="size-4" /> Record visit
          </Button>
        }
      />

      <div className="flex flex-wrap items-center gap-2">
        <Select value={doctorFilter} onValueChange={setDoctorFilter}>
          <SelectTrigger className="h-9 w-[220px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All doctors</SelectItem>
            {doctors.map((d) => (
              <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <span className="text-xs text-muted-foreground">{visits.length} visit{visits.length === 1 ? "" : "s"}</span>
      </div>

      <Card className="border-border/60">
        <CardContent className="p-0">
          {loading ? (
            <LoadingState label="Loading visits…" />
          ) : error ? (
            <EmptyState icon={Stethoscope} title="Failed to load" description={error} />
          ) : visits.length === 0 ? (
            <EmptyState
              icon={Stethoscope}
              title="No visits recorded"
              description="Record a clinical encounter to build patient history."
              action={
                <Button onClick={() => setAddOpen(true)} size="sm">
                  <Plus className="size-4" /> Record visit
                </Button>
              }
            />
          ) : (
            <div className="overflow-x-auto scrollbar-clinic">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border/60 bg-muted/30 text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="px-4 py-2.5 font-medium">Patient</th>
                    <th className="hidden px-4 py-2.5 font-medium md:table-cell">Doctor</th>
                    <th className="px-4 py-2.5 font-medium">Diagnosis</th>
                    <th className="hidden px-4 py-2.5 font-medium lg:table-cell">Vitals</th>
                    <th className="hidden px-4 py-2.5 font-medium sm:table-cell">Date</th>
                    <th className="hidden px-4 py-2.5 text-right font-medium sm:table-cell">Fee</th>
                    <th className="px-4 py-2.5 text-right font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {visits.map((v) => (
                    <tr key={v.id} className="group transition hover:bg-muted/30">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2.5">
                          <Avatar name={v.patient?.name ?? "?"} color={v.doctor?.color ?? "teal"} size="sm" />
                          <span className="truncate font-medium text-foreground">{v.patient?.name}</span>
                        </div>
                      </td>
                      <td className="hidden px-4 py-3 text-xs text-muted-foreground md:table-cell">{v.doctor?.name}</td>
                      <td className="px-4 py-3">
                        <p className="font-medium text-foreground">{v.diagnosis}</p>
                        {v.prescription && (
                          <p className="truncate text-[11px] text-muted-foreground"><span className="font-medium">Rx:</span> {v.prescription}</p>
                        )}
                      </td>
                      <td className="hidden px-4 py-3 lg:table-cell">
                        <div className="flex flex-wrap gap-1 text-[10px]">
                          {v.temperature && (
                            <span className="inline-flex items-center gap-1 rounded bg-orange-50 px-1.5 py-0.5 text-orange-700 dark:bg-orange-500/10 dark:text-orange-300">
                              <Thermometer className="size-3" />{v.temperature}°
                            </span>
                          )}
                          {v.bloodPressure && (
                            <span className="inline-flex items-center gap-1 rounded bg-rose-50 px-1.5 py-0.5 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">
                              <Activity className="size-3" />{v.bloodPressure}
                            </span>
                          )}
                          {v.weight && <span className="rounded bg-teal-50 px-1.5 py-0.5 text-teal-700 dark:bg-teal-500/10 dark:text-teal-300">{v.weight}kg</span>}
                        </div>
                      </td>
                      <td className="hidden px-4 py-3 text-xs text-muted-foreground sm:table-cell">
                        {new Date(v.visitDate).toLocaleDateString("en-US", { dateStyle: "medium" })}
                      </td>
                      <td className="hidden px-4 py-3 text-right text-xs font-semibold text-emerald-600 dark:text-emerald-400 sm:table-cell">
                        EGP {v.fee}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1 opacity-60 transition group-hover:opacity-100">
                          <Button size="icon" variant="ghost" className="size-8" title="Edit" onClick={() => setEditTarget(v)}>
                            <Pencil className="size-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" className="size-8 text-destructive hover:bg-destructive/10" title="Delete" onClick={() => setDeleteTarget(v)}>
                            <Trash2 className="size-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <VisitFormDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        patients={patients}
        doctors={doctors}
        defaultPatientId={defaultPatientId}
        onSaved={() => {
          refresh();
          onChanged();
        }}
      />

      <VisitFormDialog
        open={!!editTarget}
        onOpenChange={(v) => !v && setEditTarget(null)}
        patients={patients}
        doctors={doctors}
        visit={editTarget}
        onSaved={() => {
          setEditTarget(null);
          refresh();
          onChanged();
        }}
      />

      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete visit record?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the visit record for{" "}
              <span className="font-medium text-foreground">{deleteTarget?.patient?.name}</span> ({deleteTarget?.diagnosis}).
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-white hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
