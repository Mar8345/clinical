"use client";

import { useMemo, useState } from "react";
import { api } from "@/lib/api";
import { useFetch } from "@/hooks/use-fetch";
import type { Doctor, Patient, PatientWithRelations } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Users,
  Plus,
  Search,
  Phone,
  Mail,
  MapPin,
  Droplet,
  AlertTriangle,
  HeartPulse,
  StickyNote,
  Trash2,
  Pencil,
  CalendarDays,
  Stethoscope,
} from "lucide-react";
import { Avatar, AgeChip, DateLabel, EmptyState, GenderTag, LoadingState, SectionHeader, StatusBadge, TimeLabel } from "./shared";
import { PatientFormDialog } from "./patient-form-dialog";
import { toast } from "sonner";
import { calcAge, formatISODate } from "@/lib/clinic";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

interface Props {
  doctors: Doctor[];
  refreshKey: number;
  onChanged: () => void;
  onOpenAppointmentForPatient: (patientId: string) => void;
  onOpenVisitForPatient: (patientId: string) => void;
}

export function PatientsView({ doctors, refreshKey, onChanged, onOpenAppointmentForPatient, onOpenVisitForPatient }: Props) {
  const [search, setSearch] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Patient | null>(null);
  const [detailId, setDetailId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Patient | null>(null);

  const { data, loading, error, refresh } = useFetch(
    () => api.listPatients(search),
    [search, refreshKey],
  );

  const patients = data?.patients ?? [];

  async function handleDelete() {
    if (!deleteTarget) return;
    try {
      await api.deletePatient(deleteTarget.id);
      toast.success("Patient deleted");
      setDeleteTarget(null);
      refresh();
      onChanged();
    } catch (e) {
      toast.error("Failed to delete", { description: String((e as Error).message) });
    }
  }

  return (
    <div className="space-y-5">
      <SectionHeader
        title="Patients"
        description="Demographics, medical history and visit records."
        icon={Users}
        action={
          <Button onClick={() => setAddOpen(true)} className="shadow-sm">
            <Plus className="size-4" /> Add patient
          </Button>
        }
      />

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, phone, email…"
            className="pl-8"
          />
        </div>
        <span className="text-xs text-muted-foreground">{patients.length} patient{patients.length === 1 ? "" : "s"}</span>
      </div>

      <Card className="border-border/60">
        <CardContent className="p-0">
          {loading ? (
            <LoadingState label="Loading patients…" />
          ) : error ? (
            <EmptyState icon={Users} title="Failed to load" description={error} />
          ) : patients.length === 0 ? (
            <EmptyState
              icon={Users}
              title={search ? "No matching patients" : "No patients yet"}
              description={search ? "Try a different search term." : "Add your first patient to get started."}
              action={
                <Button onClick={() => setAddOpen(true)} size="sm">
                  <Plus className="size-4" /> Add patient
                </Button>
              }
            />
          ) : (
            <div className="overflow-x-auto scrollbar-clinic">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border/60 bg-muted/30 text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="px-4 py-2.5 font-medium">Patient</th>
                    <th className="px-4 py-2.5 font-medium">Contact</th>
                    <th className="hidden px-4 py-2.5 font-medium lg:table-cell">Details</th>
                    <th className="hidden px-4 py-2.5 text-center font-medium sm:table-cell">Visits</th>
                    <th className="hidden px-4 py-2.5 text-center font-medium sm:table-cell">Appts</th>
                    <th className="px-4 py-2.5 text-right font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {patients.map((p) => (
                    <tr
                      key={p.id}
                      className="group cursor-pointer transition hover:bg-muted/30"
                      onClick={() => setDetailId(p.id)}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <Avatar name={p.name} size="md" />
                          <div className="min-w-0">
                            <p className="truncate font-medium text-foreground">{p.name}</p>
                            <div className="flex items-center gap-2">
                              <GenderTag gender={p.gender} />
                              <AgeChip birthDate={p.birthDate} />
                              {p.bloodType && (
                                <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                                  <Droplet className="size-3 text-rose-500" /> {p.bloodType}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <Phone className="size-3" /> {p.phone}
                        </div>
                        {p.email && (
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <Mail className="size-3" /> <span className="truncate">{p.email}</span>
                          </div>
                        )}
                      </td>
                      <td className="hidden px-4 py-3 lg:table-cell">
                        <div className="space-y-1">
                          {p.allergies && (
                            <div className="flex items-center gap-1.5 text-[11px] text-amber-700 dark:text-amber-400">
                              <AlertTriangle className="size-3" /> {p.allergies}
                            </div>
                          )}
                          {p.conditions && (
                            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                              <HeartPulse className="size-3" /> {p.conditions}
                            </div>
                          )}
                          {!p.allergies && !p.conditions && (
                            <span className="text-[11px] text-muted-foreground/60">No notable conditions</span>
                          )}
                        </div>
                      </td>
                      <td className="hidden px-4 py-3 text-center sm:table-cell">
                        <span className="inline-flex min-w-6 items-center justify-center rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300">
                          {p._count?.visits ?? 0}
                        </span>
                      </td>
                      <td className="hidden px-4 py-3 text-center sm:table-cell">
                        <span className="inline-flex min-w-6 items-center justify-center rounded-full bg-teal-50 px-2 py-0.5 text-xs font-medium text-teal-700 dark:bg-teal-500/10 dark:text-teal-300">
                          {p._count?.appointments ?? 0}
                        </span>
                      </td>
                      <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1 opacity-60 transition group-hover:opacity-100">
                          <Button size="icon" variant="ghost" className="size-8" title="Edit" onClick={() => setEditTarget(p)}>
                            <Pencil className="size-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" className="size-8 text-destructive hover:bg-destructive/10" title="Delete" onClick={() => setDeleteTarget(p)}>
                            <Trash2 className="size-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add */}
      <PatientFormDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        onSaved={() => {
          refresh();
          onChanged();
        }}
      />

      {/* Edit */}
      <PatientFormDialog
        open={!!editTarget}
        onOpenChange={(v) => !v && setEditTarget(null)}
        patient={editTarget}
        onSaved={() => {
          setEditTarget(null);
          refresh();
          onChanged();
        }}
      />

      {/* Detail drawer */}
      <PatientDetail
        id={detailId}
        onOpenChange={(v) => !v && setDetailId(null)}
        onEdit={(p) => {
          setDetailId(null);
          setEditTarget(p);
        }}
        onBook={(id) => {
          setDetailId(null);
          onOpenAppointmentForPatient(id);
        }}
        onRecordVisit={(id) => {
          setDetailId(null);
          onOpenVisitForPatient(id);
        }}
      />

      {/* Delete confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete patient?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently deletes <span className="font-medium text-foreground">{deleteTarget?.name}</span> and all related appointments and visits. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-white hover:bg-destructive/90">
              Delete patient
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function PatientDetail({
  id,
  onOpenChange,
  onEdit,
  onBook,
  onRecordVisit,
}: {
  id: string | null;
  onOpenChange: (v: boolean) => void;
  onEdit: (p: Patient) => void;
  onBook: (id: string) => void;
  onRecordVisit: (id: string) => void;
}) {
  const { data, loading, error } = useFetch(
    () => (id ? api.getPatient(id) : Promise.resolve(null as unknown as { patient: PatientWithRelations })),
    [id],
  );
  const patient = data?.patient;

  return (
    <Sheet open={!!id} onOpenChange={onOpenChange}>
      <SheetContent className="flex w-full flex-col gap-0 p-0 sm:max-w-xl">
        <SheetHeader className="border-b border-border/60 bg-gradient-to-br from-primary/5 to-transparent px-5 py-4">
          {loading || !patient ? (
            <div className="space-y-2">
              <div className="h-5 w-24 animate-pulse rounded bg-muted" />
              <div className="h-4 w-40 animate-pulse rounded bg-muted/60" />
            </div>
          ) : (
            <>
              <div className="flex items-center gap-3">
                <Avatar name={patient.name} size="lg" />
                <div className="min-w-0">
                  <SheetTitle className="truncate text-lg">{patient.name}</SheetTitle>
                  <SheetDescription className="flex flex-wrap items-center gap-2">
                    <GenderTag gender={patient.gender} />
                    <AgeChip birthDate={patient.birthDate} />
                    {patient.bloodType && (
                      <span className="inline-flex items-center gap-1">
                        <Droplet className="size-3 text-rose-500" /> {patient.bloodType}
                      </span>
                    )}
                  </SheetDescription>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={() => onEdit(patient)}>
                  <Pencil className="size-3.5" /> Edit
                </Button>
                <Button size="sm" onClick={() => onBook(patient.id)}>
                  <CalendarDays className="size-3.5" /> Book
                </Button>
                <Button size="sm" variant="secondary" onClick={() => onRecordVisit(patient.id)}>
                  <Stethoscope className="size-3.5" /> Record visit
                </Button>
              </div>
            </>
          )}
        </SheetHeader>

        {loading ? (
          <LoadingState label="Loading patient record…" />
        ) : error ? (
          <EmptyState icon={Users} title="Failed to load" description={error} />
        ) : patient ? (
          <div className="flex-1 overflow-y-auto scrollbar-clinic px-5 py-4">
            {/* Contact & medical info */}
            <div className="grid gap-3 sm:grid-cols-2">
              <InfoRow icon={Phone} label="Phone" value={patient.phone} />
              <InfoRow icon={Mail} label="Email" value={patient.email ?? "—"} />
              <InfoRow icon={MapPin} label="Address" value={patient.address ?? "—"} />
              <InfoRow icon={CalendarDays} label="Date of birth" value={patient.birthDate ? `${formatISODate(patient.birthDate)} (${calcAge(patient.birthDate)}y)` : "—"} />
              <InfoRow icon={AlertTriangle} label="Allergies" value={patient.allergies || "None"} accent={patient.allergies ? "amber" : undefined} />
              <InfoRow icon={HeartPulse} label="Conditions" value={patient.conditions || "None"} />
            </div>

            {patient.notes && (
              <div className="mt-3 rounded-lg border border-border/60 bg-muted/20 p-3">
                <p className="mb-1 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                  <StickyNote className="size-3.5" /> Notes
                </p>
                <p className="text-sm text-foreground/80">{patient.notes}</p>
              </div>
            )}

            {/* Tabs: appointments + visits */}
            <Tabs defaultValue="visits" className="mt-5">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="visits" className="text-xs">
                  Visits <Badge variant="secondary" className="ml-1.5 h-4 px-1 text-[10px]">{patient.visits.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="appointments" className="text-xs">
                  Appointments <Badge variant="secondary" className="ml-1.5 h-4 px-1 text-[10px]">{patient.appointments.length}</Badge>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="visits" className="mt-3 space-y-2">
                {patient.visits.length === 0 ? (
                  <EmptyState icon={Stethoscope} title="No visits yet" description="Record the first visit." />
                ) : (
                  patient.visits.map((v) => (
                    <div key={v.id} className="rounded-lg border border-border/60 p-3">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="text-sm font-semibold text-foreground">{v.diagnosis}</p>
                          <p className="text-[11px] text-muted-foreground">{v.doctor.name} · {new Date(v.visitDate).toLocaleDateString("en-US", { dateStyle: "medium" })}</p>
                        </div>
                        {v.fee > 0 && (
                          <span className="shrink-0 text-xs font-semibold text-emerald-600 dark:text-emerald-400">EGP {v.fee}</span>
                        )}
                      </div>
                      {v.prescription && (
                        <p className="mt-2 rounded bg-muted/40 px-2 py-1 text-[11px] text-foreground/70">
                          <span className="font-medium">Rx:</span> {v.prescription}
                        </p>
                      )}
                      {(v.temperature || v.bloodPressure || v.weight) && (
                        <div className="mt-2 flex flex-wrap gap-2 text-[11px] text-muted-foreground">
                          {v.temperature && <span className="rounded bg-orange-50 px-1.5 py-0.5 dark:bg-orange-500/10">🌡 {v.temperature}°C</span>}
                          {v.bloodPressure && <span className="rounded bg-rose-50 px-1.5 py-0.5 dark:bg-rose-500/10">🩸 {v.bloodPressure}</span>}
                          {v.weight && <span className="rounded bg-teal-50 px-1.5 py-0.5 dark:bg-teal-500/10">⚖ {v.weight}kg</span>}
                          {v.height && <span className="rounded bg-violet-50 px-1.5 py-0.5 dark:bg-violet-500/10">📏 {v.height}cm</span>}
                        </div>
                      )}
                      {v.followUpDate && (
                        <p className="mt-2 text-[11px] font-medium text-amber-700 dark:text-amber-400">
                          ↪ Follow-up: {formatISODate(v.followUpDate)}
                        </p>
                      )}
                    </div>
                  ))
                )}
              </TabsContent>

              <TabsContent value="appointments" className="mt-3 space-y-2">
                {patient.appointments.length === 0 ? (
                  <EmptyState icon={CalendarDays} title="No appointments" description="Book the first appointment." />
                ) : (
                  patient.appointments.map((a) => (
                    <div key={a.id} className="flex items-center justify-between rounded-lg border border-border/60 px-3 py-2">
                      <div>
                        <p className="text-sm font-medium text-foreground">
                          <DateLabel iso={a.date} /> · <TimeLabel time={a.time} />
                        </p>
                        <p className="text-[11px] text-muted-foreground">{a.doctor.name} · {a.reason || "—"}</p>
                      </div>
                      <StatusBadge status={a.status} />
                    </div>
                  ))
                )}
              </TabsContent>
            </Tabs>
          </div>
        ) : null}
      </SheetContent>
    </Sheet>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  accent?: "amber";
}) {
  return (
    <div className="rounded-lg border border-border/50 bg-card px-3 py-2">
      <p className="mb-0.5 flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
        <Icon className={`size-3.5 ${accent === "amber" ? "text-amber-500" : "text-primary/70"}`} />
        {label}
      </p>
      <p className={`text-sm ${accent === "amber" ? "font-medium text-amber-700 dark:text-amber-400" : "text-foreground"}`}>{value}</p>
    </div>
  );
}
