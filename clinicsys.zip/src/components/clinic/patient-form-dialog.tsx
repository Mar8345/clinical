"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api } from "@/lib/api";
import type { Patient } from "@/lib/types";
import { GENDERS, BLOOD_TYPES } from "@/lib/clinic";
import { toast } from "sonner";
import { Loader2, UserPlus } from "lucide-react";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  patient?: Patient | null;
  onSaved?: (p: Patient) => void;
}

const empty = {
  name: "",
  phone: "",
  email: "",
  gender: "unknown",
  birthDate: "",
  address: "",
  bloodType: "",
  allergies: "",
  conditions: "",
  notes: "",
};

export function PatientFormDialog({ open, onOpenChange, patient, onSaved }: Props) {
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (open) {
      setErrors({});
      if (patient) {
        setForm({
          name: patient.name,
          phone: patient.phone,
          email: patient.email ?? "",
          gender: patient.gender,
          birthDate: patient.birthDate ?? "",
          address: patient.address ?? "",
          bloodType: patient.bloodType ?? "",
          allergies: patient.allergies ?? "",
          conditions: patient.conditions ?? "",
          notes: patient.notes ?? "",
        });
      } else {
        setForm(empty);
      }
    }
  }, [open, patient]);

  const set = (k: keyof typeof form, v: string) => setForm((f) => ({ ...f, [k]: v }));

  function validate() {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Full name is required";
    if (!form.phone.trim()) e.phone = "Phone number is required";
    else if (!/^[\d\s+()-]{7,}$/.test(form.phone.trim())) e.phone = "Enter a valid phone number";
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Invalid email";
    if (form.birthDate && Number.isNaN(new Date(form.birthDate).getTime())) e.birthDate = "Invalid date";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function onSubmit() {
    if (!validate()) return;
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        phone: form.phone.trim(),
        email: form.email.trim() || undefined,
        gender: form.gender,
        birthDate: form.birthDate || undefined,
        address: form.address || undefined,
        bloodType: form.bloodType || undefined,
        allergies: form.allergies || undefined,
        conditions: form.conditions || undefined,
        notes: form.notes || undefined,
      };
      let saved: Patient;
      if (patient) {
        const res = await api.updatePatient(patient.id, payload);
        saved = res.patient;
        toast.success("Patient updated", { description: saved.name });
      } else {
        const res = await api.createPatient(payload);
        saved = res.patient;
        toast.success("Patient added", { description: saved.name });
      }
      onSaved?.(saved);
      onOpenChange(false);
    } catch (err) {
      toast.error("Failed to save patient", { description: String((err as Error).message) });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto scrollbar-clinic sm:max-w-2xl">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <div className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <UserPlus className="size-5" />
            </div>
            <div>
              <DialogTitle>{patient ? "Edit Patient" : "New Patient"}</DialogTitle>
              <DialogDescription>
                {patient ? "Update patient demographic & medical info." : "Register a new patient record."}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="grid gap-4 py-2 sm:grid-cols-2">
          <Field label="Full name" required error={errors.name} className="sm:col-span-2">
            <Input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="e.g. Mariam Abdelaziz" />
          </Field>

          <Field label="Phone" required error={errors.phone}>
            <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+20 122 …" />
          </Field>

          <Field label="Email" error={errors.email}>
            <Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="name@example.com" />
          </Field>

          <Field label="Gender">
            <Select value={form.gender} onValueChange={(v) => set("gender", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {GENDERS.map((g) => (
                  <SelectItem key={g} value={g} className="capitalize">{g}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Date of birth">
            <Input type="date" value={form.birthDate} onChange={(e) => set("birthDate", e.target.value)} />
          </Field>

          <Field label="Blood type">
            <Select value={form.bloodType || "__none__"} onValueChange={(v) => set("bloodType", v === "__none__" ? "" : v)}>
              <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__none__">— None —</SelectItem>
                {BLOOD_TYPES.map((b) => (
                  <SelectItem key={b} value={b}>{b}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Address">
            <Input value={form.address} onChange={(e) => set("address", e.target.value)} placeholder="Street, city" />
          </Field>

          <Field label="Known allergies" className="sm:col-span-2">
            <Input value={form.allergies} onChange={(e) => set("allergies", e.target.value)} placeholder="e.g. Penicillin, Peanuts" />
          </Field>

          <Field label="Chronic conditions" className="sm:col-span-2">
            <Input value={form.conditions} onChange={(e) => set("conditions", e.target.value)} placeholder="e.g. Asthma, Hypertension" />
          </Field>

          <Field label="Notes" className="sm:col-span-2">
            <Textarea value={form.notes} onChange={(e) => set("notes", e.target.value)} rows={3} placeholder="Any extra notes about the patient…" />
          </Field>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={onSubmit} disabled={saving}>
            {saving && <Loader2 className="size-4 animate-spin" />}
            {patient ? "Save changes" : "Add patient"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  required,
  error,
  className,
  children,
}: {
  label: string;
  required?: boolean;
  error?: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={className}>
      <Label className="mb-1.5 flex items-center gap-1 text-xs font-medium text-foreground/80">
        {label}
        {required && <span className="text-destructive">*</span>}
      </Label>
      {children}
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}
