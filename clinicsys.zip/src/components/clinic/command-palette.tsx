"use client";

import * as React from "react";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import { api } from "@/lib/api";
import type { Doctor, Patient } from "@/lib/types";
import { Avatar } from "./shared";
import {
  Users,
  CalendarDays,
  Stethoscope,
  UserCog,
  LayoutDashboard,
  Search,
  Phone,
} from "lucide-react";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onNavigate: (view: "dashboard" | "appointments" | "patients" | "visits" | "doctors") => void;
  onPickPatient: (id: string) => void;
  onPickDoctor: (id: string) => void;
  onBookForPatient: (id: string) => void;
}

export function CommandPalette({
  open,
  onOpenChange,
  onNavigate,
  onPickPatient,
  onPickDoctor,
  onBookForPatient,
}: Props) {
  const [query, setQuery] = React.useState("");
  const [patients, setPatients] = React.useState<Patient[]>([]);
  const [doctors, setDoctors] = React.useState<Doctor[]>([]);

  React.useEffect(() => {
    if (!open) return;
    let active = true;
    (async () => {
      try {
        const [p, d] = await Promise.all([api.listPatients(), api.listDoctors()]);
        if (active) {
          setPatients(p.patients);
          setDoctors(d.doctors);
        }
      } catch {
        // ignore
      }
    })();
    return () => {
      active = false;
    };
  }, [open]);

  const q = query.trim().toLowerCase();
  const matchedPatients = q
    ? patients.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.phone.toLowerCase().includes(q) ||
          (p.email ?? "").toLowerCase().includes(q),
      )
    : patients.slice(0, 5);
  const matchedDoctors = q
    ? doctors.filter(
        (d) =>
          d.name.toLowerCase().includes(q) ||
          d.specialty.toLowerCase().includes(q),
      )
    : doctors.slice(0, 4);

  function run(fn: () => void) {
    onOpenChange(false);
    setQuery("");
    setTimeout(fn, 50);
  }

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput
        placeholder="Search patients, doctors, or jump to…"
        value={query}
        onValueChange={setQuery}
      />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>

        <CommandGroup heading="Navigate">
          <CommandItem onSelect={() => run(() => onNavigate("dashboard"))}>
            <LayoutDashboard className="mr-2 size-4 text-primary" />
            Go to Dashboard
          </CommandItem>
          <CommandItem onSelect={() => run(() => onNavigate("appointments"))}>
            <CalendarDays className="mr-2 size-4 text-primary" />
            Go to Appointments
          </CommandItem>
          <CommandItem onSelect={() => run(() => onNavigate("patients"))}>
            <Users className="mr-2 size-4 text-primary" />
            Go to Patients
          </CommandItem>
          <CommandItem onSelect={() => run(() => onNavigate("visits"))}>
            <Stethoscope className="mr-2 size-4 text-primary" />
            Go to Visits
          </CommandItem>
          <CommandItem onSelect={() => run(() => onNavigate("doctors"))}>
            <UserCog className="mr-2 size-4 text-primary" />
            Go to Doctors
          </CommandItem>
        </CommandGroup>

        <CommandSeparator />

        {matchedPatients.length > 0 && (
          <CommandGroup heading="Patients">
            {matchedPatients.map((p) => (
              <CommandItem
                key={p.id}
                value={`patient ${p.name} ${p.phone}`}
                onSelect={() => run(() => onPickPatient(p.id))}
              >
                <Avatar name={p.name} size="sm" />
                <div className="ml-2 min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{p.name}</p>
                  <p className="flex items-center gap-1 truncate text-[11px] text-muted-foreground">
                    <Phone className="size-3" /> {p.phone}
                  </p>
                </div>
              </CommandItem>
            ))}
          </CommandGroup>
        )}

        {matchedDoctors.length > 0 && (
          <CommandGroup heading="Doctors">
            {matchedDoctors.map((d) => (
              <CommandItem
                key={d.id}
                value={`doctor ${d.name} ${d.specialty}`}
                onSelect={() => run(() => onPickDoctor(d.id))}
              >
                <Avatar name={d.name} color={d.color} size="sm" />
                <div className="ml-2 min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{d.name}</p>
                  <p className="truncate text-[11px] text-muted-foreground">{d.specialty}</p>
                </div>
              </CommandItem>
            ))}
          </CommandGroup>
        )}

        {matchedPatients.length === 1 && (
          <>
            <CommandSeparator />
            <CommandGroup heading="Quick action">
              <CommandItem
                onSelect={() => run(() => onBookForPatient(matchedPatients[0].id))}
              >
                <CalendarDays className="mr-2 size-4 text-emerald-600" />
                Book appointment for {matchedPatients[0].name}
              </CommandItem>
            </CommandGroup>
          </>
        )}
      </CommandList>
    </CommandDialog>
  );
}
