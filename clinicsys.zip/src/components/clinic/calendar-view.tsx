"use client";

import { useMemo, useState } from "react";
import { api } from "@/lib/api";
import { useFetch } from "@/hooks/use-fetch";
import type { Appointment, Doctor } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  CalendarRange,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  addDaysISO,
  formatISODate,
  formatTime12,
  todayISO,
  toISODate,
  STATUS_META,
} from "@/lib/clinic";
import { Avatar, EmptyState, LoadingState } from "./shared";
import { AppointmentFormDialog } from "./appointment-form-dialog";
import type { Patient } from "@/lib/types";

interface Props {
  patients: Patient[];
  doctors: Doctor[];
  refreshKey: number;
  onChanged: () => void;
}

const HOURS = (() => {
  const arr: string[] = [];
  for (let h = 8; h <= 20; h++) {
    arr.push(`${String(h).padStart(2, "0")}:00`);
  }
  return arr;
})();

const DAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

function getWeekStart(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  const dt = new Date(y, m - 1, d);
  const day = dt.getDay(); // 0=Sun
  const offset = day === 0 ? -6 : 1 - day; // Monday start
  dt.setDate(dt.getDate() + offset);
  return toISODate(dt);
}

export function CalendarView({ patients, doctors, refreshKey, onChanged }: Props) {
  const [weekStart, setWeekStart] = useState(() => getWeekStart(todayISO()));
  const [bookOpen, setBookOpen] = useState(false);
  const [defaultDate, setDefaultDate] = useState<string | undefined>(undefined);

  const weekDays = useMemo(
    () => Array.from({ length: 7 }, (_, i) => addDaysISO(weekStart, i)),
    [weekStart],
  );
  const weekEnd = weekDays[6];

  const fetcher = useMemo(
    () => () => api.listAppointments({ from: weekStart, to: weekEnd }),
    [weekStart, weekEnd],
  );
  const { data, loading, error, refresh } = useFetch(fetcher, [weekStart, refreshKey]);

  const appointments = data?.appointments ?? [];

  // group by date
  const byDate = useMemo(() => {
    const map = new Map<string, Appointment[]>();
    for (const a of appointments) {
      const list = map.get(a.date) ?? [];
      list.push(a);
      map.set(a.date, list);
    }
    for (const list of map.values()) list.sort((x, y) => x.time.localeCompare(y.time));
    return map;
  }, [appointments]);

  const today = todayISO();

  function shiftWeek(days: number) {
    setWeekStart((w) => addDaysISO(w, days));
  }

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <CalendarRange className="size-5" />
          </div>
          <div>
            <h2 className="text-lg font-semibold tracking-tight text-foreground">Weekly Calendar</h2>
            <p className="text-xs text-muted-foreground">
              {formatISODate(weekStart)} — {formatISODate(weekEnd)}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => shiftWeek(-7)}>
            <ChevronLeft className="size-4" /> Prev
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setWeekStart(getWeekStart(today))}
            className="hidden sm:inline-flex"
          >
            This week
          </Button>
          <Button variant="outline" size="sm" onClick={() => shiftWeek(7)}>
            Next <ChevronRight className="size-4" />
          </Button>
          <Button
            size="sm"
            onClick={() => {
              setDefaultDate(today);
              setBookOpen(true);
            }}
          >
            <Plus className="size-4" /> Book
          </Button>
        </div>
      </div>

      {/* Calendar grid */}
      {loading ? (
        <LoadingState label="Loading week…" />
      ) : error ? (
        <EmptyState icon={CalendarRange} title="Failed to load" description={error} />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-7">
          {weekDays.map((iso, i) => {
            const dayAppts = byDate.get(iso) ?? [];
            const isToday = iso === today;
            const isPast = iso < today;
            return (
              <Card
                key={iso}
                className={cn(
                  "flex min-h-[200px] flex-col overflow-hidden border-border/60 p-0",
                  isToday && "ring-2 ring-primary/40",
                )}
              >
                {/* Day header */}
                <div
                  className={cn(
                    "flex items-center justify-between border-b border-border/50 px-3 py-2",
                    isToday ? "bg-primary/10" : "bg-muted/30",
                  )}
                >
                  <div>
                    <p className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                      {DAY_LABELS[i]}
                    </p>
                    <p
                      className={cn(
                        "text-sm font-bold tabular-nums",
                        isToday ? "text-primary" : "text-foreground",
                      )}
                    >
                      {Number(iso.slice(8, 10))}
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      setDefaultDate(iso);
                      setBookOpen(true);
                    }}
                    className="flex size-6 items-center justify-center rounded-md text-muted-foreground transition hover:bg-primary/10 hover:text-primary"
                    title="Book on this day"
                  >
                    <Plus className="size-3.5" />
                  </button>
                </div>

                {/* Appointments */}
                <div className="flex-1 space-y-1.5 overflow-y-auto scrollbar-clinic p-2">
                  {dayAppts.length === 0 ? (
                    <p className={cn("px-1 py-6 text-center text-[11px] text-muted-foreground/60", isPast && "opacity-50")}>
                      No appointments
                    </p>
                  ) : (
                    dayAppts.map((a) => (
                      <button
                        key={a.id}
                        onClick={() => {
                          setDefaultDate(iso);
                          setBookOpen(true);
                        }}
                        className="group block w-full rounded-lg border border-border/40 bg-card p-2 text-left transition hover:border-primary/40 hover:shadow-sm"
                      >
                        <div className="flex items-center gap-1.5">
                          <span
                            className={cn("size-1.5 shrink-0 rounded-full", STATUS_META[a.status]?.dotClass)}
                          />
                          <span className="text-[11px] font-semibold tabular-nums text-foreground">
                            {formatTime12(a.time)}
                          </span>
                          <span className="ml-auto text-[9px] uppercase text-muted-foreground">
                            {a.durationMin}m
                          </span>
                        </div>
                        <div className="mt-1 flex items-center gap-1.5">
                          <Avatar name={a.patient?.name ?? "?"} color={a.doctor?.color ?? "teal"} size="sm" />
                          <div className="min-w-0">
                            <p className="truncate text-[11px] font-medium leading-tight text-foreground">
                              {a.patient?.name}
                            </p>
                            <p className="truncate text-[10px] leading-tight text-muted-foreground">
                              {a.doctor?.name}
                            </p>
                          </div>
                        </div>
                      </button>
                    ))
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 rounded-lg border border-border/50 bg-muted/20 px-4 py-2.5 text-[11px] text-muted-foreground">
        <span className="font-medium text-foreground/70">Status:</span>
        {Object.entries(STATUS_META).map(([k, m]) => (
          <span key={k} className="inline-flex items-center gap-1.5">
            <span className={cn("size-2 rounded-full", m.dotClass)} />
            {m.label}
          </span>
        ))}
      </div>

      <AppointmentFormDialog
        open={bookOpen}
        onOpenChange={(v) => {
          setBookOpen(v);
          if (!v) setDefaultDate(undefined);
        }}
        patients={patients}
        doctors={doctors}
        defaultDate={defaultDate}
        onSaved={() => {
          refresh();
          onChanged();
        }}
      />
    </div>
  );
}
