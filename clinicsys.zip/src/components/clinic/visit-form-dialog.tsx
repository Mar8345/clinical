"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api } from "@/lib/api";
import type { Appointment, Doctor, Patient, Visit } from "@/lib/types";
import { toast } from "sonner";
import { Loader2, Stethoscope } from "lucide-react";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  patients: Patient[];
  doctors: Doctor[];
  visit?: Visit | null;
  defaultPatientId?: string;
  defaultDoctorId?: string;
  appointment?: Appointment | null;
  onSaved?: (v: Visit) => void;
}

export function VisitFormDialog({
  open,
  onOpenChange,
  patients,
  doctors,
  visit,
  defaultPatientId,
  defaultDoctorId,
  appointment,
  onSaved,
}: Props) {
  const [form, setForm] = useState({
    patientId: "",
    doctorId: "",
    diagnosis: "",
    prescription: "",
    notes: "",
    temperature: "",
    bloodPressure: "",
    weight: "",
    height: "",
    fee: "",
    followUpDate: "",
    visitDate: "",
  });
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!open) return;
    setErrors({});
    if (visit) {
      const d = new Date(visit.visitDate);
      setForm({
        patientId: visit.patientId,
        doctorId: visit.doctorId,
        diagnosis: visit.diagnosis,
        prescription: visit.prescription ?? "",
        notes: visit.notes ?? "",
        temperature: visit.temperature ?? "",
        bloodPressure: visit.bloodPressure ?? "",
        weight: visit.weight ?? "",
        height: visit.height ?? "",
        fee: String(visit.fee || ""),
        followUpDate: visit.followUpDate ?? "",
        visitDate: d.toISOString().slice(0, 16),
      });
    } else {
      const now = new Date();
      setForm({
        patientId: defaultPatientId ?? appointment?.patientId ?? "",
        doctorId: defaultDoctorId ?? appointment?.doctorId ?? doctors[0]?.id ?? "",
        diagnosis: "",
        prescription: "",
        notes: "",
        temperature: "",
        bloodPressure: "",
        weight: "",
        height: "",
        fee: "",
        followUpDate: "",
        visitDate: now.toISOString().slice(0, 16),
      });
    }
  }, [open, visit, defaultPatientId, defaultDoctorId, appointment, doctors]);

  const set = (k: keyof typeof form, v: string) => setForm((f) => ({ ...f, [k]: v }));

  function validate() {
    const e: Record<string, string> = {};
    if (!form.patientId) e.patientId = "Select a patient";
    if (!form.doctorId) e.doctorId = "Select a doctor";
    if (!form.diagnosis.trim()) e.diagnosis = "Diagnosis is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function onSubmit() {
    if (!validate()) return;
    setSaving(true);
    try {
      if (visit) {
        const res = await api.updateVisit(visit.id, {
          diagnosis: form.diagnosis,
          prescription: form.prescription,
          notes: form.notes,
          temperature: form.temperature,
          bloodPressure: form.bloodPressure,
          weight: form.weight,
          height: form.height,
          fee: form.fee ? Number(form.fee) : 0,
          followUpDate: form.followUpDate || undefined,
        });
        toast.success("Visit record updated");
        onSaved?.(res.visit);
        onOpenChange(false);
      } else {
        const res = await api.createVisit({
          patientId: form.patientId,
          doctorId: form.doctorId,
          appointmentId: appointment?.id ?? undefined,
          visitDate: form.visitDate ? new Date(form.visitDate).toISOString() : undefined,
          diagnosis: form.diagnosis,
          prescription: form.prescription,
          notes: form.notes,
          temperature: form.temperature,
          bloodPressure: form.bloodPressure,
          weight: form.weight,
          height: form.height,
          fee: form.fee ? Number(form.fee) : 0,
          followUpDate: form.followUpDate || undefined,
        });
        toast.success("Visit recorded");
        onSaved?.(res.visit);
        onOpenChange(false);
      }
    } catch (err) {
      toast.error("Failed to save visit", { description: String((err as Error).message) });
    } finally {
      setSaving(false);
    }
  }

  const inputCls = "h-9";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto scrollbar-clinic sm:max-w-2xl">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <div className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Stethoscope className="size-5" />
            </div>
            <div>
              <DialogTitle>{visit ? "Edit Visit Record" : "Record Visit"}</DialogTitle>
              <DialogDescription>
                {visit ? "Update diagnosis, prescription & vitals." : "Capture the clinical encounter."}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="grid gap-4 py-2 sm:grid-cols-2">
          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Patient <span className="text-destructive">*</span></Label>
            <Select value={form.patientId} onValueChange={(v) => set("patientId", v)} disabled={!!visit}>
              <SelectTrigger className={errors.patientId ? "border-destructive" : ""}>
                <SelectValue placeholder="Select patient" />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                {patients.map((p) => (
                  <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Doctor <span className="text-destructive">*</span></Label>
            <Select value={form.doctorId} onValueChange={(v) => set("doctorId", v)} disabled={!!visit}>
              <SelectTrigger className={errors.doctorId ? "border-destructive" : ""}>
                <SelectValue placeholder="Select doctor" />
              </SelectTrigger>
              <SelectContent>
                {doctors.map((d) => (
                  <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="sm:col-span-2">
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Diagnosis <span className="text-destructive">*</span></Label>
            <Input
              value={form.diagnosis}
              onChange={(e) => set("diagnosis", e.target.value)}
              placeholder="e.g. Acute bronchitis"
              className={errors.diagnosis ? "border-destructive" : ""}
            />
            {errors.diagnosis && <p className="mt-1 text-xs text-destructive">{errors.diagnosis}</p>}
          </div>

          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Temperature (°C)</Label>
            <Input className={inputCls} value={form.temperature} onChange={(e) => set("temperature", e.target.value)} placeholder="37.0" inputMode="decimal" />
          </div>
          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Blood pressure</Label>
            <Input className={inputCls} value={form.bloodPressure} onChange={(e) => set("bloodPressure", e.target.value)} placeholder="120/80" />
          </div>
          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Weight (kg)</Label>
            <Input className={inputCls} value={form.weight} onChange={(e) => set("weight", e.target.value)} placeholder="72" inputMode="decimal" />
          </div>
          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Height (cm)</Label>
            <Input className={inputCls} value={form.height} onChange={(e) => set("height", e.target.value)} placeholder="170" inputMode="decimal" />
          </div>

          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Consultation fee</Label>
            <Input className={inputCls} value={form.fee} onChange={(e) => set("fee", e.target.value)} placeholder="250" inputMode="decimal" />
          </div>
          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Follow-up date</Label>
            <Input className={inputCls} type="date" value={form.followUpDate} onChange={(e) => set("followUpDate", e.target.value)} />
          </div>

          <div className="sm:col-span-2">
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Prescription</Label>
            <Textarea value={form.prescription} onChange={(e) => set("prescription", e.target.value)} rows={2} placeholder="Medications & dosage…" />
          </div>

          <div className="sm:col-span-2">
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Clinical notes</Label>
            <Textarea value={form.notes} onChange={(e) => set("notes", e.target.value)} rows={2} placeholder="Observations, advice…" />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={onSubmit} disabled={saving}>
            {saving && <Loader2 className="size-4 animate-spin" />}
            {visit ? "Save changes" : "Record visit"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
