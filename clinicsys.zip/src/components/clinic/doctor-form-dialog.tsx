"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { api } from "@/lib/api";
import type { Doctor } from "@/lib/types";
import { toast } from "sonner";
import { Loader2, UserCog } from "lucide-react";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  doctor?: Doctor | null;
  onSaved?: (d: Doctor) => void;
}

const COLORS = [
  { value: "teal", label: "Teal", cls: "bg-teal-500" },
  { value: "emerald", label: "Emerald", cls: "bg-emerald-500" },
  { value: "rose", label: "Rose", cls: "bg-rose-500" },
  { value: "amber", label: "Amber", cls: "bg-amber-500" },
  { value: "violet", label: "Violet", cls: "bg-violet-500" },
];

export function DoctorFormDialog({ open, onOpenChange, doctor, onSaved }: Props) {
  const [form, setForm] = useState({
    name: "",
    specialty: "",
    email: "",
    phone: "",
    bio: "",
    color: "teal",
    active: true,
  });
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!open) return;
    setErrors({});
    if (doctor) {
      setForm({
        name: doctor.name,
        specialty: doctor.specialty,
        email: doctor.email ?? "",
        phone: doctor.phone ?? "",
        bio: doctor.bio ?? "",
        color: doctor.color,
        active: doctor.active,
      });
    } else {
      setForm({ name: "", specialty: "", email: "", phone: "", bio: "", color: "teal", active: true });
    }
  }, [open, doctor]);

  const set = (k: keyof typeof form, v: string | boolean) => setForm((f) => ({ ...f, [k]: v }));

  function validate() {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Doctor name is required";
    if (!form.specialty.trim()) e.specialty = "Specialty is required";
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Invalid email";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function onSubmit() {
    if (!validate()) return;
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        specialty: form.specialty.trim(),
        email: form.email.trim() || undefined,
        phone: form.phone.trim() || undefined,
        bio: form.bio || undefined,
        color: form.color,
        active: form.active,
      };
      let saved: Doctor;
      if (doctor) {
        saved = (await api.updateDoctor(doctor.id, payload)).doctor;
        toast.success("Doctor updated", { description: saved.name });
      } else {
        saved = (await api.createDoctor(payload)).doctor;
        toast.success("Doctor added", { description: saved.name });
      }
      onSaved?.(saved);
      onOpenChange(false);
    } catch (err) {
      toast.error("Failed to save doctor", { description: String((err as Error).message) });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto scrollbar-clinic sm:max-w-lg">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <div className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <UserCog className="size-5" />
            </div>
            <div>
              <DialogTitle>{doctor ? "Edit Doctor" : "Add Doctor"}</DialogTitle>
              <DialogDescription>{doctor ? "Update doctor profile." : "Register a new doctor."}</DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="grid gap-4 py-2">
          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Full name <span className="text-destructive">*</span></Label>
            <Input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Dr. …" className={errors.name ? "border-destructive" : ""} />
            {errors.name && <p className="mt-1 text-xs text-destructive">{errors.name}</p>}
          </div>
          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Specialty <span className="text-destructive">*</span></Label>
            <Input value={form.specialty} onChange={(e) => set("specialty", e.target.value)} placeholder="e.g. Cardiologist" className={errors.specialty ? "border-destructive" : ""} />
            {errors.specialty && <p className="mt-1 text-xs text-destructive">{errors.specialty}</p>}
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Email</Label>
              <Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="name@clinic.io" className={errors.email ? "border-destructive" : ""} />
            </div>
            <div>
              <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Phone</Label>
              <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+20 100 …" />
            </div>
          </div>
          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Bio</Label>
            <Textarea value={form.bio} onChange={(e) => set("bio", e.target.value)} rows={2} placeholder="Short professional bio…" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Card color</Label>
              <div className="flex items-center gap-2">
                {COLORS.map((c) => (
                  <button
                    key={c.value}
                    type="button"
                    onClick={() => set("color", c.value)}
                    className={`size-8 rounded-full ring-2 ring-offset-2 ring-offset-background transition ${c.cls} ${form.color === c.value ? "ring-foreground/40 scale-110" : "ring-transparent"}`}
                    aria-label={c.label}
                    title={c.label}
                  />
                ))}
              </div>
            </div>
            <div className="flex items-center justify-between rounded-lg border border-border/70 px-3 py-2">
              <div>
                <Label className="text-xs font-medium text-foreground/80">Active</Label>
                <p className="text-[11px] text-muted-foreground">Available for booking</p>
              </div>
              <Switch checked={form.active} onCheckedChange={(v) => set("active", v)} />
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={onSubmit} disabled={saving}>
            {saving && <Loader2 className="size-4 animate-spin" />}
            {doctor ? "Save changes" : "Add doctor"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
