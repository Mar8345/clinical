"use client";

import { useMemo } from "react";
import { api } from "@/lib/api";
import { useFetch } from "@/hooks/use-fetch";
import type { DashboardData } from "@/lib/types";
import {
  Users,
  CalendarCheck,
  CalendarClock,
  Stethoscope,
  Activity,
  TrendingUp,
  Clock,
  CircleDollarSign,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, DateLabel, EmptyState, LoadingState, StatusBadge, TimeLabel } from "./shared";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
} from "recharts";
import { STATUS_META } from "@/lib/clinic";
import { calcAge } from "@/lib/clinic";

const STATUS_COLORS: Record<string, string> = {
  pending: "#f59e0b",
  confirmed: "#14b8a6",
  completed: "#10b981",
  cancelled: "#f43f5e",
  no_show: "#a1a1aa",
};

export function DashboardView({ refreshKey }: { refreshKey: number }) {
  const { data, loading, error } = useFetch(() => api.dashboard(), [refreshKey]);

  if (loading) return <LoadingState label="Loading dashboard…" />;
  if (error || !data) {
    return (
      <EmptyState
        icon={Activity}
        title="Couldn't load dashboard"
        description={error ?? "Unknown error"}
      />
    );
  }

  return <DashboardContent data={data} />;
}

function DashboardContent({ data }: { data: DashboardData }) {
  const stats = [
    {
      label: "Total Patients",
      value: data.totals.patients,
      icon: Users,
      tint: "from-teal-500/15 to-teal-500/5 text-teal-600 dark:text-teal-400",
      sub: "Registered records",
    },
    {
      label: "Today's Appointments",
      value: data.totals.todayCount,
      icon: CalendarCheck,
      tint: "from-emerald-500/15 to-emerald-500/5 text-emerald-600 dark:text-emerald-400",
      sub: `${data.totals.upcomingCount} upcoming`,
    },
    {
      label: "Total Visits",
      value: data.totals.visits,
      icon: Stethoscope,
      tint: "from-amber-500/15 to-amber-500/5 text-amber-600 dark:text-amber-400",
      sub: "Recorded encounters",
    },
    {
      label: "Revenue",
      value: `EGP ${data.totals.revenue.toLocaleString()}`,
      icon: CircleDollarSign,
      tint: "from-rose-500/15 to-rose-500/5 text-rose-600 dark:text-rose-400",
      sub: "From visit fees",
    },
  ];

  const statusPieData = useMemo(
    () =>
      Object.entries(data.statusCounts)
        .filter(([, v]) => v > 0)
        .map(([k, v]) => ({ name: STATUS_META[k as keyof typeof STATUS_META]?.label ?? k, value: v, key: k })),
    [data.statusCounts],
  );

  const chartData = data.last14Days.map((d) => ({
    date: d.date.slice(5),
    total: d.total,
    completed: d.completed,
  }));

  return (
    <div className="space-y-6">
      {/* Stat cards */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="relative overflow-hidden border-border/60 shadow-sm">
            <div className={`pointer-events-none absolute -right-6 -top-6 size-28 rounded-full bg-gradient-to-br ${s.tint} opacity-50 blur-2xl`} />
            <CardContent className="relative p-5">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{s.label}</p>
                  <p className="text-2xl font-bold tracking-tight text-foreground">{s.value}</p>
                  <p className="text-[11px] text-muted-foreground">{s.sub}</p>
                </div>
                <div className={`flex size-10 items-center justify-center rounded-xl bg-gradient-to-br ${s.tint}`}>
                  <s.icon className="size-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="size-4 text-primary" />
              Appointments — last 14 days
            </CardTitle>
            <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
              <span className="inline-flex items-center gap-1"><span className="size-2 rounded-full bg-teal-500" /> Total</span>
              <span className="inline-flex items-center gap-1"><span className="size-2 rounded-full bg-emerald-500" /> Completed</span>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[260px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                  <defs>
                    <linearGradient id="gTotal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.35} />
                      <stop offset="95%" stopColor="#14b8a6" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gDone" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.35} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.9 0.02 180)" vertical={false} />
                  <XAxis dataKey="date" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: "oklch(0.52 0.03 185)" }} />
                  <YAxis allowDecimals={false} tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: "oklch(0.52 0.03 185)" }} />
                  <Tooltip
                    contentStyle={{
                      borderRadius: 12,
                      border: "1px solid oklch(0.9 0.02 180)",
                      boxShadow: "0 8px 24px rgba(0,0,0,0.08)",
                      fontSize: 12,
                    }}
                  />
                  <Area type="monotone" dataKey="total" stroke="#14b8a6" strokeWidth={2} fill="url(#gTotal)" />
                  <Area type="monotone" dataKey="completed" stroke="#10b981" strokeWidth={2} fill="url(#gDone)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Activity className="size-4 text-primary" />
              Appointment status
            </CardTitle>
          </CardHeader>
          <CardContent>
            {statusPieData.length === 0 ? (
              <EmptyState icon={Activity} title="No appointments yet" />
            ) : (
              <div className="h-[220px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={statusPieData}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={48}
                      outerRadius={80}
                      paddingAngle={3}
                      stroke="none"
                    >
                      {statusPieData.map((entry) => (
                        <Cell key={entry.key} fill={STATUS_COLORS[entry.key]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ borderRadius: 12, border: "1px solid oklch(0.9 0.02 180)", fontSize: 12 }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
            <div className="mt-2 grid grid-cols-2 gap-1.5">
              {statusPieData.map((s) => (
                <div key={s.key} className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                  <span className="size-2 rounded-full" style={{ backgroundColor: STATUS_COLORS[s.key] }} />
                  <span className="font-medium text-foreground/80">{s.name}</span>
                  <span className="ml-auto tabular-nums">{s.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Today + doctor load */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Clock className="size-4 text-primary" />
              Today's schedule
            </CardTitle>
            <span className="text-xs text-muted-foreground">{data.todayAppointments.length} booked</span>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-[340px] overflow-y-auto scrollbar-clinic px-2 pb-2">
              {data.todayAppointments.length === 0 ? (
                <div className="px-4 pb-4">
                  <EmptyState icon={CalendarCheck} title="Nothing scheduled today" description="Book an appointment to get started." />
                </div>
              ) : (
                <ul className="space-y-1">
                  {data.todayAppointments.map((a) => (
                    <li
                      key={a.id}
                      className="flex items-center gap-3 rounded-lg px-3 py-2 transition hover:bg-muted/50"
                    >
                      <div className="flex w-14 shrink-0 flex-col items-center">
                        <span className="text-sm font-semibold tabular-nums text-foreground">
                          <TimeLabel time={a.time} />
                        </span>
                        <span className="text-[10px] uppercase text-muted-foreground">{a.durationMin}m</span>
                      </div>
                      <div className="h-9 w-px bg-border/70" />
                      <Avatar name={a.patient.name} color={a.doctor.color} size="sm" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-foreground">{a.patient.name}</p>
                        <p className="truncate text-[11px] text-muted-foreground">
                          {a.doctor.name} · {a.reason || "—"}
                        </p>
                      </div>
                      <StatusBadge status={a.status} />
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <CalendarClock className="size-4 text-primary" />
              Doctor workload
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[220px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.doctorLoad} layout="vertical" margin={{ top: 4, right: 12, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.9 0.02 180)" horizontal={false} />
                  <XAxis type="number" allowDecimals={false} tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: "oklch(0.52 0.03 185)" }} />
                  <YAxis type="category" dataKey="doctor" width={90} tickLine={false} axisLine={false} tick={{ fontSize: 10, fill: "oklch(0.52 0.03 185)" }} />
                  <Tooltip cursor={{ fill: "oklch(0.94 0.04 170 / 0.5)" }} contentStyle={{ borderRadius: 12, border: "1px solid oklch(0.9 0.02 180)", fontSize: 12 }} />
                  <Bar dataKey="count" name="Appointments" fill="#14b8a6" radius={[0, 6, 6, 0]} barSize={16} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming + recent visits */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <CalendarClock className="size-4 text-primary" />
              Upcoming appointments
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-80 overflow-y-auto scrollbar-clinic px-2 pb-2">
              {data.upcomingAppointments.length === 0 ? (
                <div className="px-4 pb-4">
                  <EmptyState icon={CalendarClock} title="No upcoming appointments" />
                </div>
              ) : (
                <ul className="space-y-1">
                  {data.upcomingAppointments.map((a) => (
                    <li key={a.id} className="flex items-center gap-3 rounded-lg px-3 py-2 hover:bg-muted/50">
                      <Avatar name={a.patient.name} color={a.doctor.color} size="sm" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-foreground">{a.patient.name}</p>
                        <p className="truncate text-[11px] text-muted-foreground">{a.doctor.name} · {a.reason || "—"}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs font-medium text-foreground"><DateLabel iso={a.date} /></p>
                        <p className="text-[11px] text-muted-foreground"><TimeLabel time={a.time} /></p>
                      </div>
                      <StatusBadge status={a.status} />
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Stethoscope className="size-4 text-primary" />
              Recent visits
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-80 overflow-y-auto scrollbar-clinic px-2 pb-2">
              {data.recentVisits.length === 0 ? (
                <div className="px-4 pb-4">
                  <EmptyState icon={Stethoscope} title="No visits recorded yet" />
                </div>
              ) : (
                <ul className="space-y-1">
                  {data.recentVisits.map((v) => (
                    <li key={v.id} className="flex items-start gap-3 rounded-lg px-3 py-2 hover:bg-muted/50">
                      <Avatar name={v.patient.name} color={v.doctor.color} size="sm" />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <p className="truncate text-sm font-medium text-foreground">{v.patient.name}</p>
                          {v.patient.birthDate && (
                            <span className="rounded bg-muted px-1 text-[10px] text-muted-foreground tabular-nums">
                              {calcAge(v.patient.birthDate)}y
                            </span>
                          )}
                        </div>
                        <p className="truncate text-[11px] text-muted-foreground">{v.diagnosis}</p>
                        <p className="text-[10px] text-muted-foreground">
                          {v.doctor.name} · {new Date(v.visitDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                        </p>
                      </div>
                      <span className="shrink-0 text-[11px] font-medium text-emerald-600 dark:text-emerald-400">
                        EGP {v.fee}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
