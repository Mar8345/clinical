"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import type { Doctor, Patient } from "@/lib/types";
import {
  LayoutDashboard,
  CalendarDays,
  Users,
  Stethoscope,
  UserCog,
  HeartPulse,
  Menu,
  Sparkles,
  Database,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { todayISO, formatISODate } from "@/lib/clinic";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { LoadingState } from "./shared";

import { DashboardView } from "./dashboard-view";
import { AppointmentsView } from "./appointments-view";
import { PatientsView } from "./patients-view";
import { VisitsView } from "./visits-view";
import { DoctorsView } from "./doctors-view";

type ViewKey = "dashboard" | "appointments" | "patients" | "visits" | "doctors";

const NAV: { key: ViewKey; label: string; icon: React.ComponentType<{ className?: string }>; description: string }[] = [
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard, description: "Overview & stats" },
  { key: "appointments", label: "Appointments", icon: CalendarDays, description: "Booking & tracking" },
  { key: "patients", label: "Patients", icon: Users, description: "Records & history" },
  { key: "visits", label: "Visits", icon: Stethoscope, description: "Clinical encounters" },
  { key: "doctors", label: "Doctors", icon: UserCog, description: "Practitioner roster" },
];

export function AppShell() {
  const [view, setView] = useState<ViewKey>("dashboard");
  const [mobileNav, setMobileNav] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [globalRefresh, setGlobalRefresh] = useState(0);

  // Shared doctors/patients lists
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loadingLists, setLoadingLists] = useState(true);
  const [seeding, setSeeding] = useState(false);

  // Cross-view signals
  const [apptSignal, setApptSignal] = useState<{ patientId: string; ts: number } | null>(null);
  const [visitSignal, setVisitSignal] = useState<{ patientId: string; ts: number } | null>(null);

  async function loadLists() {
    setLoadingLists(true);
    try {
      const [d, p] = await Promise.all([api.listDoctors(), api.listPatients()]);
      setDoctors(d.doctors);
      setPatients(p.patients);
    } catch {
      // ignore — views handle their own errors
    } finally {
      setLoadingLists(false);
    }
  }

  useEffect(() => {
    loadLists();
  }, [globalRefresh]);

  function bumpAll() {
    setGlobalRefresh((x) => x + 1);
    setRefreshKey((x) => x + 1);
  }

  async function handleSeed() {
    setSeeding(true);
    try {
      const res = await api.seed();
      toast.success("Demo data loaded", {
        description: `${res.counts.doctors} doctors · ${res.counts.patients} patients · ${res.counts.appointments} appointments`,
      });
      bumpAll();
    } catch (e) {
      toast.error("Failed to seed data", { description: String((e as Error).message) });
    } finally {
      setSeeding(false);
    }
  }

  function openAppointmentForPatient(patientId: string) {
    setView("appointments");
    setApptSignal({ patientId, ts: Date.now() });
  }

  function openVisitForPatient(patientId: string) {
    setView("visits");
    setVisitSignal({ patientId, ts: Date.now() });
  }

  const go = (k: ViewKey) => {
    setView(k);
    setMobileNav(false);
  };

  return (
    <div className="flex min-h-screen flex-col bg-clinic-grid">
      {/* Top bar */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-7xl items-center gap-3 px-4">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setMobileNav(true)}
            aria-label="Open menu"
          >
            <Menu className="size-5" />
          </Button>

          <div className="flex items-center gap-2.5">
            <div className="flex size-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white shadow-sm">
              <HeartPulse className="size-5" />
            </div>
            <div className="leading-tight">
              <p className="text-sm font-bold tracking-tight text-foreground">MediClinic</p>
              <p className="hidden text-[10px] text-muted-foreground sm:block">Clinic Management System</p>
            </div>
          </div>

          <div className="ml-auto flex items-center gap-2">
            <div className="hidden items-center gap-1.5 rounded-lg border border-border/60 bg-muted/40 px-2.5 py-1.5 text-xs text-muted-foreground md:flex">
              <CalendarDays className="size-3.5 text-primary" />
              <span className="font-medium text-foreground">{formatISODate(todayISO())}</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleSeed}
              disabled={seeding}
              className="hidden sm:inline-flex"
              title="Load demo data"
            >
              {seeding ? <Sparkles className="size-4 animate-pulse" /> : <Database className="size-4" />}
              {seeding ? "Loading…" : "Demo data"}
            </Button>
          </div>
        </div>

        {/* Desktop nav tabs */}
        <div className="mx-auto hidden max-w-7xl px-4 lg:block">
          <nav className="flex gap-1 border-t border-border/40 pt-1.5">
            {NAV.map((item) => (
              <button
                key={item.key}
                onClick={() => go(item.key)}
                className={cn(
                  "group relative flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition",
                  view === item.key
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-muted/60 hover:text-foreground",
                )}
              >
                <item.icon className="size-4" />
                {item.label}
                {view === item.key && (
                  <span className="absolute inset-x-3 -bottom-1.5 h-0.5 rounded-full bg-primary" />
                )}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Desktop sidebar layout */}
      <div className="mx-auto flex w-full max-w-7xl flex-1 gap-6 px-4 py-6">
        {/* Mobile bottom nav */}
        <nav className="fixed inset-x-0 bottom-0 z-40 flex items-center justify-around border-t border-border/60 bg-background/95 backdrop-blur-md lg:hidden">
          {NAV.map((item) => (
            <button
              key={item.key}
              onClick={() => go(item.key)}
              className={cn(
                "flex flex-1 flex-col items-center gap-0.5 py-2.5 text-[10px] font-medium transition",
                view === item.key ? "text-primary" : "text-muted-foreground",
              )}
            >
              <item.icon className={cn("size-5", view === item.key && "scale-110")} />
              {item.label}
            </button>
          ))}
        </nav>

        {/* Main content */}
        <main className="min-w-0 flex-1 pb-20 lg:pb-0">
          {loadingLists && view !== "dashboard" ? (
            <LoadingState label="Preparing workspace…" />
          ) : view === "dashboard" ? (
            <DashboardView refreshKey={globalRefresh} />
          ) : view === "appointments" ? (
            <AppointmentsView
              patients={patients}
              doctors={doctors}
              refreshKey={globalRefresh}
              openSignal={apptSignal}
              onChanged={bumpAll}
            />
          ) : view === "patients" ? (
            <PatientsView
              doctors={doctors}
              refreshKey={globalRefresh}
              onChanged={bumpAll}
              onOpenAppointmentForPatient={openAppointmentForPatient}
              onOpenVisitForPatient={openVisitForPatient}
            />
          ) : view === "visits" ? (
            <VisitsView
              patients={patients}
              doctors={doctors}
              refreshKey={globalRefresh}
              openSignal={visitSignal}
              onChanged={bumpAll}
            />
          ) : (
            <DoctorsView refreshKey={globalRefresh} onChanged={bumpAll} />
          )}
        </main>
      </div>

      {/* Footer */}
      <footer className="mt-auto border-t border-border/60 bg-muted/20">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-4 text-xs text-muted-foreground sm:flex-row">
          <div className="flex items-center gap-1.5">
            <HeartPulse className="size-3.5 text-primary" />
            <span>MediClinic — small clinic management system</span>
          </div>
          <div className="flex items-center gap-3">
            <span>Appointment booking · Patient data · Visit history</span>
          </div>
        </div>
      </footer>

      {/* Mobile nav sheet */}
      <Sheet open={mobileNav} onOpenChange={setMobileNav}>
        <SheetContent side="left" className="w-72 p-0">
          <SheetHeader className="border-b border-border/60 px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex size-8 items-center justify-center rounded-lg bg-gradient-to-br from-teal-500 to-emerald-600 text-white">
                  <HeartPulse className="size-4" />
                </div>
                <SheetTitle>MediClinic</SheetTitle>
              </div>
              <Button variant="ghost" size="icon" className="size-8" onClick={() => setMobileNav(false)}>
                <X className="size-4" />
              </Button>
            </div>
          </SheetHeader>
          <nav className="flex flex-col gap-1 p-3">
            {NAV.map((item) => (
              <button
                key={item.key}
                onClick={() => go(item.key)}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-left transition",
                  view === item.key
                    ? "bg-primary/10 text-primary"
                    : "text-foreground hover:bg-muted",
                )}
              >
                <item.icon className="size-5" />
                <div>
                  <p className="text-sm font-medium">{item.label}</p>
                  <p className="text-[11px] text-muted-foreground">{item.description}</p>
                </div>
              </button>
            ))}
            <div className="mt-3 border-t border-border/60 pt-3">
              <Button variant="outline" className="w-full" onClick={handleSeed} disabled={seeding}>
                <Database className="size-4" /> {seeding ? "Loading…" : "Load demo data"}
              </Button>
            </div>
          </nav>
        </SheetContent>
      </Sheet>
    </div>
  );
}
