"use client";

import { useState } from "react";
import { api } from "@/lib/api";
import { useFetch } from "@/hooks/use-fetch";
import type { Doctor } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Stethoscope, Trash2, Pencil, Mail, Phone, CalendarCheck, ClipboardList } from "lucide-react";
import { Avatar, EmptyState, LoadingState, SectionHeader } from "./shared";
import { DoctorFormDialog } from "./doctor-form-dialog";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";

interface Props {
  refreshKey: number;
  onChanged: () => void;
}

const COLOR_DOT: Record<string, string> = {
  teal: "bg-teal-500",
  emerald: "bg-emerald-500",
  rose: "bg-rose-500",
  amber: "bg-amber-500",
  violet: "bg-violet-500",
};

export function DoctorsView({ refreshKey, onChanged }: Props) {
  const [addOpen, setAddOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Doctor | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Doctor | null>(null);

  const { data, loading, error, refresh } = useFetch(() => api.listDoctors(), [refreshKey]);
  const doctors = data?.doctors ?? [];

  async function handleDelete() {
    if (!deleteTarget) return;
    try {
      await api.deleteDoctor(deleteTarget.id);
      toast.success("Doctor removed");
      setDeleteTarget(null);
      refresh();
      onChanged();
    } catch (e) {
      toast.error("Failed to delete", { description: String((e as Error).message) });
    }
  }

  return (
    <div className="space-y-5">
      <SectionHeader
        title="Doctors"
        description="Manage practitioners, specialties and availability."
        icon={Stethoscope}
        action={
          <Button onClick={() => setAddOpen(true)} className="shadow-sm">
            <Plus className="size-4" /> Add doctor
          </Button>
        }
      />

      {loading ? (
        <LoadingState label="Loading doctors…" />
      ) : error ? (
        <EmptyState icon={Stethoscope} title="Failed to load" description={error} />
      ) : doctors.length === 0 ? (
        <EmptyState
          icon={Stethoscope}
          title="No doctors yet"
          description="Add practitioners to start booking appointments."
          action={
            <Button onClick={() => setAddOpen(true)} size="sm">
              <Plus className="size-4" /> Add doctor
            </Button>
          }
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {doctors.map((d) => (
            <Card key={d.id} className="group relative overflow-hidden border-border/60 transition hover:shadow-md">
              <div className={`absolute inset-x-0 top-0 h-1 ${COLOR_DOT[d.color] ?? "bg-teal-500"}`} />
              <CardContent className="p-5">
                <div className="flex items-start gap-3">
                  <Avatar name={d.name} color={d.color} size="lg" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="truncate font-semibold text-foreground">{d.name}</h3>
                      {d.active ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-1.5 py-0.5 text-[10px] font-medium text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300">
                          <span className="size-1.5 rounded-full bg-emerald-500" /> Active
                        </span>
                      ) : (
                        <Badge variant="secondary" className="text-[10px]">Inactive</Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">{d.specialty}</p>
                  </div>
                </div>

                {d.bio && <p className="mt-3 line-clamp-2 text-xs text-foreground/70">{d.bio}</p>}

                <div className="mt-3 space-y-1">
                  {d.phone && (
                    <a href={`tel:${d.phone}`} className="flex items-center gap-2 text-xs text-muted-foreground hover:text-primary">
                      <Phone className="size-3.5" /> {d.phone}
                    </a>
                  )}
                  {d.email && (
                    <a href={`mailto:${d.email}`} className="flex items-center gap-2 text-xs text-muted-foreground hover:text-primary">
                      <Mail className="size-3.5" /> <span className="truncate">{d.email}</span>
                    </a>
                  )}
                </div>

                <div className="mt-4 flex items-center justify-between border-t border-border/50 pt-3">
                  <div className="flex gap-4 text-xs text-muted-foreground">
                    <span className="inline-flex items-center gap-1">
                      <CalendarCheck className="size-3.5 text-teal-500" />
                      <span className="font-semibold text-foreground">{d._count?.appointments ?? 0}</span> appts
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <ClipboardList className="size-3.5 text-emerald-500" />
                      <span className="font-semibold text-foreground">{d._count?.visits ?? 0}</span> visits
                    </span>
                  </div>
                  <div className="flex gap-1 opacity-60 transition group-hover:opacity-100">
                    <Button size="icon" variant="ghost" className="size-8" title="Edit" onClick={() => setEditTarget(d)}>
                      <Pencil className="size-3.5" />
                    </Button>
                    <Button size="icon" variant="ghost" className="size-8 text-destructive hover:bg-destructive/10" title="Remove" onClick={() => setDeleteTarget(d)}>
                      <Trash2 className="size-3.5" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <DoctorFormDialog open={addOpen} onOpenChange={setAddOpen} onSaved={() => { refresh(); onChanged(); }} />
      <DoctorFormDialog
        open={!!editTarget}
        onOpenChange={(v) => !v && setEditTarget(null)}
        doctor={editTarget}
        onSaved={() => {
          setEditTarget(null);
          refresh();
          onChanged();
        }}
      />

      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove doctor?</AlertDialogTitle>
            <AlertDialogDescription>
              Removing <span className="font-medium text-foreground">{deleteTarget?.name}</span> will also delete all related appointments and visits. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-white hover:bg-destructive/90">
              Remove doctor
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
