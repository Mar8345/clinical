"use client";

import { useMemo, useState } from "react";
import { api } from "@/lib/api";
import { useFetch } from "@/hooks/use-fetch";
import type { Appointment, AppointmentStatus, Doctor, Patient } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CalendarDays, Plus, Search, Trash2, CalendarPlus, Stethoscope, Filter } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, DateLabel, EmptyState, LoadingState, SectionHeader, StatusBadge, TimeLabel } from "./shared";
import { AppointmentFormDialog } from "./appointment-form-dialog";
import { VisitFormDialog } from "./visit-form-dialog";
import { APPOINTMENT_STATUSES, STATUS_META, todayISO } from "@/lib/clinic";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface Props {
  patients: Patient[];
  doctors: Doctor[];
  refreshKey: number;
  onChanged: () => void;
  openSignal?: { patientId: string; ts: number } | null;
}

export function AppointmentsView({ patients, doctors, refreshKey, onChanged, openSignal }: Props) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<string>(todayISO());
  const [scope, setScope] = useState<"today" | "all" | "upcoming">("today");
  const [bookOpen, setBookOpen] = useState(false);
  const [defaultPatientId, setDefaultPatientId] = useState<string | undefined>(undefined);
  const [editTarget, setEditTarget] = useState<Appointment | null>(null);
  const [visitTarget, setVisitTarget] = useState<Appointment | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Appointment | null>(null);

  // Open book dialog when triggered from patient detail (render-time state adjust)
  const [prevSignalTs, setPrevSignalTs] = useState<number | null>(null);
  if (openSignal && openSignal.ts !== prevSignalTs) {
    setPrevSignalTs(openSignal.ts);
    setDefaultPatientId(openSignal.patientId);
    setBookOpen(true);
  }

  // Fetch appointments based on scope
  const fetcher = useMemo(() => {
    return () => {
      if (scope === "upcoming") return api.listAppointments({ upcoming: "true" });
      if (scope === "all") return api.listAppointments({});
      return api.listAppointments({ date: dateFilter });
    };
  }, [scope, dateFilter]);

  const { data, loading, error, refresh } = useFetch(fetcher, [scope, dateFilter, refreshKey]);

  const appointments = data?.appointments ?? [];

  const filtered = useMemo(() => {
    return appointments.filter((a) => {
      if (statusFilter !== "all" && a.status !== statusFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        const matches =
          a.patient?.name.toLowerCase().includes(q) ||
          a.doctor?.name.toLowerCase().includes(q) ||
          (a.reason ?? "").toLowerCase().includes(q);
        if (!matches) return false;
      }
      return true;
    });
  }, [appointments, statusFilter, search]);

  async function changeStatus(id: string, status: AppointmentStatus) {
    try {
      await api.patchAppointment(id, { status });
      toast.success(`Marked as ${STATUS_META[status].label.toLowerCase()}`);
      refresh();
      onChanged();
    } catch (e) {
      toast.error("Failed to update status", { description: String((e as Error).message) });
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    try {
      await api.deleteAppointment(deleteTarget.id);
      toast.success("Appointment deleted");
      setDeleteTarget(null);
      refresh();
      onChanged();
    } catch (e) {
      toast.error("Failed to delete", { description: String((e as Error).message) });
    }
  }

  const doctorMap = useMemo(() => new Map(doctors.map((d) => [d.id, d])), [doctors]);

  return (
    <div className="space-y-5">
      <SectionHeader
        title="Appointments"
        description="Book, reschedule and track the status of every visit."
        icon={CalendarDays}
        action={
          <Button onClick={() => setBookOpen(true)} className="shadow-sm">
            <Plus className="size-4" /> Book appointment
          </Button>
        }
      />

      {/* Scope tabs */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="inline-flex rounded-lg border border-border/70 bg-muted/40 p-1">
          {([
            { k: "today", label: "Today" },
            { k: "upcoming", label: "Upcoming" },
            { k: "all", label: "All" },
          ] as const).map((t) => (
            <button
              key={t.k}
              onClick={() => setScope(t.k)}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition ${
                scope === t.k
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {scope === "today" && (
          <Input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="h-9 w-auto"
          />
        )}

        <div className="relative ml-auto">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search patient, doctor, reason…"
            className="h-9 w-full pl-8 sm:w-64"
          />
        </div>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="h-9 w-[140px]">
            <Filter className="mr-1 size-3.5 text-muted-foreground" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {APPOINTMENT_STATUSES.map((s) => (
              <SelectItem key={s} value={s} className="capitalize">{STATUS_META[s].label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* List */}
      <Card className="border-border/60">
        <CardContent className="p-0">
          {loading ? (
            <LoadingState label="Loading appointments…" />
          ) : error ? (
            <EmptyState icon={CalendarDays} title="Failed to load" description={error} />
          ) : filtered.length === 0 ? (
            <EmptyState
              icon={CalendarDays}
              title="No appointments match"
              description="Try adjusting the filters or book a new appointment."
              action={
                <Button onClick={() => setBookOpen(true)} size="sm">
                  <Plus className="size-4" /> Book appointment
                </Button>
              }
            />
          ) : (
            <div className="divide-y divide-border/50">
              {filtered.map((a) => (
                <div
                  key={a.id}
                  className="group flex flex-col gap-3 px-4 py-3 transition hover:bg-muted/30 sm:flex-row sm:items-center"
                >
                  <div className="flex w-full items-center gap-3 sm:w-auto sm:min-w-[180px]">
                    <div className="flex flex-col items-center rounded-lg bg-primary/5 px-3 py-1.5">
                      <span className="text-[10px] font-medium uppercase tracking-wide text-primary/80">
                        {scope === "all" ? a.date.slice(5) : a.date === todayISO() ? "Today" : a.date.slice(5)}
                      </span>
                      <span className="text-sm font-semibold tabular-nums text-foreground">
                        <TimeLabel time={a.time} />
                      </span>
                    </div>
                  </div>

                  <Avatar name={a.patient?.name ?? "?"} color={a.doctor?.color ?? "teal"} size="sm" />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="truncate text-sm font-semibold text-foreground">{a.patient?.name}</p>
                      <StatusBadge status={a.status} />
                    </div>
                    <p className="truncate text-[11px] text-muted-foreground">
                      {a.doctor?.name} · {a.reason || "No reason given"}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    {a.status !== "completed" && a.status !== "cancelled" && (
                      <>
                        {a.status === "pending" && (
                          <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => changeStatus(a.id, "confirmed")}>
                            Confirm
                          </Button>
                        )}
                        <Button size="sm" variant="outline" className="h-7 text-xs text-emerald-700 dark:text-emerald-400" onClick={() => setVisitTarget(a)}>
                          <Stethoscope className="size-3.5" /> Record visit
                        </Button>
                        <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => changeStatus(a.id, "cancelled")}>
                          Cancel
                        </Button>
                      </>
                    )}
                    {a.status === "completed" && a.visit && (
                      <span className="rounded-md bg-emerald-50 px-2 py-1 text-[11px] font-medium text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300">
                        Visit recorded
                      </span>
                    )}
                    {a.status === "no_show" && (
                      <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => changeStatus(a.id, "confirmed")}>
                        Re-confirm
                      </Button>
                    )}
                    <Button size="icon" variant="ghost" className="size-7" title="Reschedule" onClick={() => setEditTarget(a)}>
                      <CalendarPlus className="size-3.5" />
                    </Button>
                    <Button size="icon" variant="ghost" className="size-7 text-destructive hover:bg-destructive/10" title="Delete" onClick={() => setDeleteTarget(a)}>
                      <Trash2 className="size-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Book dialog */}
      <AppointmentFormDialog
        open={bookOpen}
        onOpenChange={(v) => {
          setBookOpen(v);
          if (!v) setDefaultPatientId(undefined);
        }}
        patients={patients}
        doctors={doctors}
        defaultPatientId={defaultPatientId}
        onSaved={() => {
          refresh();
          onChanged();
        }}
      />

      {/* Edit / reschedule */}
      <AppointmentFormDialog
        open={!!editTarget}
        onOpenChange={(v) => !v && setEditTarget(null)}
        patients={patients}
        doctors={doctors}
        appointment={editTarget}
        onSaved={() => {
          setEditTarget(null);
          refresh();
          onChanged();
        }}
      />

      {/* Record visit from appointment */}
      <VisitFormDialog
        open={!!visitTarget}
        onOpenChange={(v) => !v && setVisitTarget(null)}
        patients={patients}
        doctors={doctors}
        appointment={visitTarget}
        onSaved={() => {
          setVisitTarget(null);
          refresh();
          onChanged();
        }}
      />

      {/* Delete confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete appointment?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove the appointment for{" "}
              <span className="font-medium text-foreground">{deleteTarget?.patient?.name}</span> on{" "}
              <DateLabel iso={deleteTarget?.date ?? ""} />. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
