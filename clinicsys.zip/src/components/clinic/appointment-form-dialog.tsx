"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api } from "@/lib/api";
import type { Appointment, Doctor, Patient } from "@/lib/types";
import { APPOINTMENT_STATUSES, todayISO } from "@/lib/clinic";
import { toast } from "sonner";
import { Loader2, CalendarPlus } from "lucide-react";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  patients: Patient[];
  doctors: Doctor[];
  defaultPatientId?: string;
  defaultDate?: string;
  appointment?: Appointment | null;
  onSaved?: (a: Appointment) => void;
}

const TIME_SLOTS = (() => {
  const slots: string[] = [];
  for (let h = 8; h <= 20; h++) {
    slots.push(`${String(h).padStart(2, "0")}:00`);
    slots.push(`${String(h).padStart(2, "0")}:30`);
  }
  return slots;
})();

export function AppointmentFormDialog({
  open,
  onOpenChange,
  patients,
  doctors,
  defaultPatientId,
  defaultDate,
  appointment,
  onSaved,
}: Props) {
  const [form, setForm] = useState({
    patientId: "",
    doctorId: "",
    date: todayISO(),
    time: "09:00",
    durationMin: 30,
    status: "pending" as string,
    reason: "",
    notes: "",
  });
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (open) {
      setErrors({});
      if (appointment) {
        setForm({
          patientId: appointment.patientId,
          doctorId: appointment.doctorId,
          date: appointment.date,
          time: appointment.time,
          durationMin: appointment.durationMin,
          status: appointment.status,
          reason: appointment.reason ?? "",
          notes: appointment.notes ?? "",
        });
      } else {
        setForm((f) => ({
          ...f,
          patientId: defaultPatientId ?? "",
          doctorId: doctors[0]?.id ?? "",
          date: defaultDate ?? todayISO(),
          time: "09:00",
          durationMin: 30,
          status: "pending",
          reason: "",
          notes: "",
        }));
      }
    }
  }, [open, appointment, defaultPatientId, defaultDate, doctors]);

  const set = (k: keyof typeof form, v: string | number) =>
    setForm((f) => ({ ...f, [k]: v }));

  function validate() {
    const e: Record<string, string> = {};
    if (!form.patientId) e.patientId = "Select a patient";
    if (!form.doctorId) e.doctorId = "Select a doctor";
    if (!/^\d{4}-\d{2}-\d{2}$/.test(form.date)) e.date = "Pick a valid date";
    if (!/^\d{2}:\d{2}$/.test(form.time)) e.time = "Pick a valid time";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function onSubmit() {
    if (!validate()) return;
    setSaving(true);
    try {
      if (appointment) {
        const res = await api.patchAppointment(appointment.id, {
          patientId: form.patientId,
          doctorId: form.doctorId,
          date: form.date,
          time: form.time,
          durationMin: form.durationMin,
          status: form.status,
          reason: form.reason,
          notes: form.notes,
        });
        toast.success("Appointment updated");
        onSaved?.(res.appointment);
        onOpenChange(false);
      } else {
        const res = await api.createAppointment({
          patientId: form.patientId,
          doctorId: form.doctorId,
          date: form.date,
          time: form.time,
          durationMin: form.durationMin,
          status: form.status,
          reason: form.reason,
          notes: form.notes,
        });
        toast.success("Appointment booked", {
          description: `${res.appointment.patient?.name} · ${res.appointment.doctor?.name}`,
        });
        onSaved?.(res.appointment);
        onOpenChange(false);
      }
    } catch (err) {
      toast.error("Failed to save appointment", { description: String((err as Error).message) });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto scrollbar-clinic sm:max-w-xl">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <div className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <CalendarPlus className="size-5" />
            </div>
            <div>
              <DialogTitle>{appointment ? "Reschedule Appointment" : "Book Appointment"}</DialogTitle>
              <DialogDescription>
                {appointment ? "Update appointment details or status." : "Schedule a new visit slot."}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="grid gap-4 py-2 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">
              Patient <span className="text-destructive">*</span>
            </Label>
            <Select value={form.patientId} onValueChange={(v) => set("patientId", v)}>
              <SelectTrigger className={errors.patientId ? "border-destructive" : ""}>
                <SelectValue placeholder="Select patient" />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                {patients.length === 0 && (
                  <div className="px-3 py-2 text-xs text-muted-foreground">No patients yet.</div>
                )}
                {patients.map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.name} · {p.phone}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.patientId && <p className="mt-1 text-xs text-destructive">{errors.patientId}</p>}
          </div>

          <div className="sm:col-span-2">
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">
              Doctor <span className="text-destructive">*</span>
            </Label>
            <Select value={form.doctorId} onValueChange={(v) => set("doctorId", v)}>
              <SelectTrigger className={errors.doctorId ? "border-destructive" : ""}>
                <SelectValue placeholder="Select doctor" />
              </SelectTrigger>
              <SelectContent>
                {doctors.map((d) => (
                  <SelectItem key={d.id} value={d.id}>
                    {d.name} · {d.specialty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.doctorId && <p className="mt-1 text-xs text-destructive">{errors.doctorId}</p>}
          </div>

          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">
              Date <span className="text-destructive">*</span>
            </Label>
            <Input type="date" value={form.date} onChange={(e) => set("date", e.target.value)} className={errors.date ? "border-destructive" : ""} />
            {errors.date && <p className="mt-1 text-xs text-destructive">{errors.date}</p>}
          </div>

          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">
              Time <span className="text-destructive">*</span>
            </Label>
            <Select value={form.time} onValueChange={(v) => set("time", v)}>
              <SelectTrigger className={errors.time ? "border-destructive" : ""}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-64">
                {TIME_SLOTS.map((t) => (
                  <SelectItem key={t} value={t}>{t}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.time && <p className="mt-1 text-xs text-destructive">{errors.time}</p>}
          </div>

          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Duration (min)</Label>
            <Select value={String(form.durationMin)} onValueChange={(v) => set("durationMin", Number(v))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {[15, 30, 45, 60, 90].map((d) => (
                  <SelectItem key={d} value={String(d)}>{d} min</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Status</Label>
            <Select value={form.status} onValueChange={(v) => set("status", v)}>
              <SelectTrigger className="capitalize"><SelectValue /></SelectTrigger>
              <SelectContent>
                {APPOINTMENT_STATUSES.map((s) => (
                  <SelectItem key={s} value={s} className="capitalize">{s.replace("_", " ")}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="sm:col-span-2">
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Reason for visit</Label>
            <Input value={form.reason} onChange={(e) => set("reason", e.target.value)} placeholder="e.g. Routine check-up" />
          </div>

          <div className="sm:col-span-2">
            <Label className="mb-1.5 block text-xs font-medium text-foreground/80">Notes</Label>
            <Textarea value={form.notes} onChange={(e) => set("notes", e.target.value)} rows={2} placeholder="Optional notes…" />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={onSubmit} disabled={saving}>
            {saving && <Loader2 className="size-4 animate-spin" />}
            {appointment ? "Save changes" : "Book appointment"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
