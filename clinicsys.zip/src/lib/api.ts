// Thin API client wrappers around fetch
import type {
  Appointment,
  AppointmentStatus,
  DashboardData,
  Doctor,
  Patient,
  PatientWithRelations,
  Visit,
} from "./types";

async function req<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers || {}) },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || `Request failed (${res.status})`);
  }
  return data as T;
}

export const api = {
  // Dashboard
  dashboard: () => req<DashboardData>("/api/dashboard"),

  // Seed
  seed: () => req<{ success: boolean; counts: Record<string, number> }>("/api/seed", { method: "POST" }),

  // Patients
  listPatients: (search?: string) =>
    req<{ patients: Patient[] }>(`/api/patients${search ? `?search=${encodeURIComponent(search)}` : ""}`),
  getPatient: (id: string) => req<{ patient: PatientWithRelations }>(`/api/patients/${id}`),
  createPatient: (data: Partial<Patient>) =>
    req<{ patient: Patient }>("/api/patients", { method: "POST", body: JSON.stringify(data) }),
  updatePatient: (id: string, data: Partial<Patient>) =>
    req<{ patient: Patient }>(`/api/patients/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  deletePatient: (id: string) =>
    req<{ success: boolean }>(`/api/patients/${id}`, { method: "DELETE" }),

  // Doctors
  listDoctors: () => req<{ doctors: Doctor[] }>("/api/doctors"),
  createDoctor: (data: Partial<Doctor>) =>
    req<{ doctor: Doctor }>("/api/doctors", { method: "POST", body: JSON.stringify(data) }),
  updateDoctor: (id: string, data: Partial<Doctor>) =>
    req<{ doctor: Doctor }>(`/api/doctors/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  deleteDoctor: (id: string) =>
    req<{ success: boolean }>(`/api/doctors/${id}`, { method: "DELETE" }),

  // Appointments
  listAppointments: (params: Record<string, string> = {}) => {
    const qs = new URLSearchParams(params).toString();
    return req<{ appointments: Appointment[] }>(`/api/appointments${qs ? `?${qs}` : ""}`);
  },
  createAppointment: (data: Record<string, unknown>) =>
    req<{ appointment: Appointment }>("/api/appointments", { method: "POST", body: JSON.stringify(data) }),
  patchAppointment: (id: string, data: Record<string, unknown>) =>
    req<{ appointment: Appointment }>(`/api/appointments/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  deleteAppointment: (id: string) =>
    req<{ success: boolean }>(`/api/appointments/${id}`, { method: "DELETE" }),

  // Visits
  listVisits: (params: Record<string, string> = {}) => {
    const qs = new URLSearchParams(params).toString();
    return req<{ visits: Visit[] }>(`/api/visits${qs ? `?${qs}` : ""}`);
  },
  createVisit: (data: Record<string, unknown>) =>
    req<{ visit: Visit }>("/api/visits", { method: "POST", body: JSON.stringify(data) }),
  updateVisit: (id: string, data: Record<string, unknown>) =>
    req<{ visit: Visit }>(`/api/visits/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  deleteVisit: (id: string) =>
    req<{ success: boolean }>(`/api/visits/${id}`, { method: "DELETE" }),
};

export type { AppointmentStatus };
