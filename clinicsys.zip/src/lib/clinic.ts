// Shared clinic domain constants & helpers

export const APPOINTMENT_STATUSES = [
  "pending",
  "confirmed",
  "completed",
  "cancelled",
  "no_show",
] as const;
export type AppointmentStatus = (typeof APPOINTMENT_STATUSES)[number];

export const VISIT_STATUSES = APPOINTMENT_STATUSES; // alias

export const GENDERS = ["male", "female", "other", "unknown"] as const;
export type Gender = (typeof GENDERS)[number];

export const BLOOD_TYPES = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

export const STATUS_META: Record<
  AppointmentStatus,
  { label: string; color: string; badgeClass: string; dotClass: string }
> = {
  pending: {
    label: "Pending",
    color: "amber",
    badgeClass:
      "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-500/15 dark:text-amber-300 dark:border-amber-500/30",
    dotClass: "bg-amber-500",
  },
  confirmed: {
    label: "Confirmed",
    color: "teal",
    badgeClass:
      "bg-teal-100 text-teal-800 border-teal-200 dark:bg-teal-500/15 dark:text-teal-300 dark:border-teal-500/30",
    dotClass: "bg-teal-500",
  },
  completed: {
    label: "Completed",
    color: "emerald",
    badgeClass:
      "bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-500/15 dark:text-emerald-300 dark:border-emerald-500/30",
    dotClass: "bg-emerald-500",
  },
  cancelled: {
    label: "Cancelled",
    color: "rose",
    badgeClass:
      "bg-rose-100 text-rose-800 border-rose-200 dark:bg-rose-500/15 dark:text-rose-300 dark:border-rose-500/30",
    dotClass: "bg-rose-500",
  },
  no_show: {
    label: "No Show",
    color: "zinc",
    badgeClass:
      "bg-zinc-100 text-zinc-700 border-zinc-200 dark:bg-zinc-500/15 dark:text-zinc-300 dark:border-zinc-500/30",
    dotClass: "bg-zinc-400",
  },
};

export const GENDER_META: Record<Gender, { label: string; emoji: string }> = {
  male: { label: "Male", emoji: "♂" },
  female: { label: "Female", emoji: "♀" },
  other: { label: "Other", emoji: "⚧" },
  unknown: { label: "Unknown", emoji: "?" },
};

export function isValidStatus(s: string): s is AppointmentStatus {
  return (APPOINTMENT_STATUSES as readonly string[]).includes(s);
}

export function isValidGender(s: string): s is Gender {
  return (GENDERS as readonly string[]).includes(s);
}

// ISO date helpers (store as local YYYY-MM-DD to avoid TZ surprises in SQLite)
export function todayISO(): string {
  const d = new Date();
  return toISODate(d);
}

export function toISODate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function addDaysISO(iso: string, days: number): string {
  const [y, m, d] = iso.split("-").map(Number);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + days);
  return toISODate(dt);
}

export function formatTime12(time: string): string {
  const [h, m] = time.split(":").map(Number);
  const period = h >= 12 ? "PM" : "AM";
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${hour12}:${String(m).padStart(2, "0")} ${period}`;
}

export function formatISODate(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  if (!y || !m || !d) return iso;
  const dt = new Date(y, m - 1, d);
  return dt.toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function calcAge(birthISO?: string | null): number | null {
  if (!birthISO) return null;
  const [y, m, d] = birthISO.split("-").map(Number);
  if (!y || !m || !d) return null;
  const birth = new Date(y, m - 1, d);
  const now = new Date();
  let age = now.getFullYear() - birth.getFullYear();
  const monthDiff = now.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < birth.getDate())) {
    age--;
  }
  return age >= 0 ? age : null;
}
