// Shared TypeScript types matching Prisma models

export type Gender = "male" | "female" | "other" | "unknown";

export type AppointmentStatus =
  | "pending"
  | "confirmed"
  | "completed"
  | "cancelled"
  | "no_show";

export interface Patient {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  gender: Gender;
  birthDate: string | null;
  address: string | null;
  bloodType: string | null;
  allergies: string | null;
  conditions: string | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  _count?: { appointments: number; visits: number };
}

export interface PatientWithRelations extends Patient {
  appointments: (Appointment & { doctor: Doctor; visit: Visit | null })[];
  visits: (Visit & { doctor: Doctor })[];
}

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  email: string | null;
  phone: string | null;
  bio: string | null;
  color: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
  _count?: { appointments: number; visits: number };
}

export interface Appointment {
  id: string;
  patientId: string;
  doctorId: string;
  date: string;
  time: string;
  durationMin: number;
  status: AppointmentStatus;
  reason: string | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  patient?: Patient;
  doctor?: Doctor;
  visit?: Visit | null;
}

export interface Visit {
  id: string;
  patientId: string;
  doctorId: string;
  appointmentId: string | null;
  visitDate: string;
  diagnosis: string;
  prescription: string | null;
  notes: string | null;
  temperature: string | null;
  bloodPressure: string | null;
  weight: string | null;
  height: string | null;
  fee: number;
  followUpDate: string | null;
  createdAt: string;
  patient?: Patient;
  doctor?: Doctor;
  appointment?: Appointment | null;
}

export interface DashboardData {
  totals: {
    patients: number;
    doctors: number;
    appointments: number;
    visits: number;
    revenue: number;
    todayCount: number;
    upcomingCount: number;
  };
  todayAppointments: (Appointment & { patient: Patient; doctor: Doctor })[];
  upcomingAppointments: (Appointment & { patient: Patient; doctor: Doctor })[];
  statusCounts: Record<AppointmentStatus, number>;
  last14Days: { date: string; total: number; completed: number }[];
  recentVisits: (Visit & { patient: Patient; doctor: Doctor })[];
  doctorLoad: { doctor: string; specialty: string; count: number }[];
}
